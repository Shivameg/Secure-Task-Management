import { Injectable, Inject, Optional } from '@nestjs/common';
import { AuditAction, CreateAuditLogDto } from '@secure-task-management/data';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class AuditLoggerService {
  private repository: any;

  constructor(@Optional() @Inject('AUDIT_LOG_REPOSITORY') repository?: any) {
    this.repository = repository;
  }

  async logAction(
    userId: number,
    action: AuditAction,
    resource: string,
    resourceId?: number,
    details?: string,
  ): Promise<void> {
    const logEntry: CreateAuditLogDto = {
      userId,
      action,
      resource,
      resourceId,
      details,
    };

    // Log to console
    console.log(`[AUDIT] ${new Date().toISOString()} | User ${userId} | ${action} | ${resource} ${resourceId || ''} | ${details || ''}`);

    // Save to database if repository is available
    if (this.repository) {
      try {
        await this.repository.save(logEntry);
      } catch (error) {
        console.error('Failed to save audit log to database:', error);
      }
    }
  }
}