import { SetMetadata } from '@nestjs/common';
import { PermissionAction, PermissionResource } from '@secure-task-management/data';

export const Permissions = (action: PermissionAction, resource: PermissionResource) => 
  SetMetadata('permissions', { action, resource });