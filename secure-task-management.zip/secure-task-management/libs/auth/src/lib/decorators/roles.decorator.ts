import { SetMetadata } from '@nestjs/common';
import { UserRole } from '@secure-task-management/data';

export const Roles = (...roles: UserRole[]) => SetMetadata('roles', roles);