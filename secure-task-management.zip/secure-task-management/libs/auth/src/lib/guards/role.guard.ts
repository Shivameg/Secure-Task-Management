import { CanActivate, ExecutionContext, Injectable, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { UserRole } from '@secure-task-management/data';

@Injectable()
export class RoleGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<UserRole[]>('roles', [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!requiredRoles) {
      return true;
    }

    const { user } = context.switchToHttp().getRequest();

    if (!user) {
      throw new ForbiddenException('User not authenticated');
    }

    const hasRole = requiredRoles.some(role => {
      // Role inheritance logic
      switch (user.role) {
        case UserRole.OWNER:
          return true; // Owner can do anything
        case UserRole.ADMIN:
          return role !== UserRole.OWNER; // Admin can do anything except owner tasks
        case UserRole.VIEWER:
          return role === UserRole.VIEWER; // Viewer can only do viewer tasks
        default:
          return false;
      }
    });

    if (!hasRole) {
      throw new ForbiddenException(`User with role ${user.role} does not have sufficient permissions`);
    }

    return true;
  }
}