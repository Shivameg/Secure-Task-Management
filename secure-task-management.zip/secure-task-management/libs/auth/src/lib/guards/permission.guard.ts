import { CanActivate, ExecutionContext, Injectable, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PermissionAction, PermissionResource, UserRole } from '@secure-task-management/data';

@Injectable()
export class PermissionGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredPermissions = this.reflector.getAllAndOverride<{
      action: PermissionAction;
      resource: PermissionResource;
    }>('permissions', [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!requiredPermissions) {
      return true;
    }

    const { user } = context.switchToHttp().getRequest();

    if (!user) {
      throw new ForbiddenException('User not authenticated');
    }

    // Check if user has the required permission based on role
    const hasPermission = this.checkPermission(
      user.role,
      requiredPermissions.action,
      requiredPermissions.resource,
    );

    if (!hasPermission) {
      throw new ForbiddenException(`User with role ${user.role} does not have permission to ${requiredPermissions.action} ${requiredPermissions.resource}`);
    }

    return true;
  }

  private checkPermission(
    role: UserRole,
    action: PermissionAction,
    resource: PermissionResource,
  ): boolean {
    // Role-based permission logic
    switch (role) {
      case UserRole.OWNER:
        return true; // Owner can do anything

      case UserRole.ADMIN:
        // Admin can do anything except certain operations
        if (resource === PermissionResource.ORGANIZATION && action === PermissionAction.DELETE) {
          return false;
        }
        return true;

      case UserRole.VIEWER:
        // Viewer can only read most resources
        if (action === PermissionAction.READ) {
          return true;
        }
        // Viewers can create/update their own tasks
        if (resource === PermissionResource.TASK && 
            (action === PermissionAction.CREATE || action === PermissionAction.UPDATE)) {
          return true;
        }
        return false;

      default:
        return false;
    }
  }
}