export function data(): string {
  return 'data';
}
