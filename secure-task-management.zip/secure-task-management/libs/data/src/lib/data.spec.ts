import { data } from './data';

describe('data', () => {
  it('should work', () => {
    expect(data()).toEqual('data');
  });
});
