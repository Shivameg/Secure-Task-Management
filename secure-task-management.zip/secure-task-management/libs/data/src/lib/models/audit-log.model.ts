export enum AuditAction {
  CREATE = 'create',
  READ = 'read',
  UPDATE = 'update',
  DELETE = 'delete',
  LOGIN = 'login',
  LOGOUT = 'logout',
}

import { User } from './user.model';

export interface AuditLog {
  id: number;
  userId: number;
  user?: User;
  action: AuditAction;
  resource: string;
  resourceId?: number;
  details?: string;
  createdAt: Date;
}

export interface CreateAuditLogDto {
  userId: number;
  action: AuditAction;
  resource: string;
  resourceId?: number;
  details?: string;
}