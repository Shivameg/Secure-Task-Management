export interface Organization {
  id: number;
  name: string;
  description?: string;
  parentOrgId?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateOrganizationDto {
  name: string;
  description?: string;
  parentOrgId?: number;
}

export interface UpdateOrganizationDto {
  name?: string;
  description?: string;
  parentOrgId?: number;
}