export enum PermissionAction {
  CREATE = 'create',
  READ = 'read',
  UPDATE = 'update',
  DELETE = 'delete',
}

export enum PermissionResource {
  TASK = 'task',
  USER = 'user',
  ORGANIZATION = 'organization',
  AUDIT_LOG = 'audit_log',
}

export interface Permission {
  id: number;
  action: PermissionAction;
  resource: PermissionResource;
  roleId: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreatePermissionDto {
  action: PermissionAction;
  resource: PermissionResource;
  roleId: number;
}

export interface UpdatePermissionDto {
  action?: PermissionAction;
  resource?: PermissionResource;
  roleId?: number;
}