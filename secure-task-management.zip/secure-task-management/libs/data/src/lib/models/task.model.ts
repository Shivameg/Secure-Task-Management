export enum TaskStatus {
  TODO = 'todo',
  IN_PROGRESS = 'in_progress',
  DONE = 'done',
}

export enum TaskCategory {
  WORK = 'work',
  PERSONAL = 'personal',
}

export interface Task {
  id: number;
  title: string;
  description?: string;
  status: TaskStatus;
  category: TaskCategory;
  dueDate?: Date;
  priority: number;
  userId: number;
  organizationId: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateTaskDto {
  title: string;
  description?: string;
  status?: TaskStatus;
  category?: TaskCategory;
  dueDate?: Date;
  priority?: number;
  organizationId?: number;
}

export interface UpdateTaskDto {
  title?: string;
  description?: string;
  status?: TaskStatus;
  category?: TaskCategory;
  dueDate?: Date;
  priority?: number;
  organizationId?: number;
}