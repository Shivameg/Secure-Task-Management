# data

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build data` to build the library.

## Running unit tests

Run `nx test data` to execute the unit tests via [Jest](https://jestjs.io).
