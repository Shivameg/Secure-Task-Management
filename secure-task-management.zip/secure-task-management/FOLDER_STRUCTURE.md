# Folder Structure Overview

This document provides an in-depth explanation of the project's folder structure and the purpose of each component.

## NX Monorepo Structure

```
secure-task-management/
├── apps/
│   ├── api/                      # NestJS backend application
│   │   ├── src/
│   │   │   ├── app/
│   │   │   │   ├── config/       # Application configuration
│   │   │   │   ├── controllers/  # API endpoints
│   │   │   │   ├── entities/     # TypeORM entity definitions
│   │   │   │   ├── guards/       # Authentication guards
│   │   │   │   ├── services/     # Business logic
│   │   │   │   ├── strategies/   # Authentication strategies
│   │   │   │   ├── app.module.ts # Main application module
│   │   │   │   └── app.service.ts
│   │   │   └── main.ts          # Application entry point
│   │   ├── tsconfig.json        # TypeScript configuration
│   │   └── project.json        # NX project configuration
│   │
│   └── dashboard/               # Angular frontend application
│       ├── src/
│       │   ├── app/
│       │   │   ├── core/        # Core functionality
│       │   │   │   ├── guards/       # Route guards
│       │   │   │   ├── interceptors/ # HTTP interceptors
│       │   │   │   ├── services/     # API services
│       │   │   │   └── state/        # NgRx state management
│       │   │   ├── features/    # Feature modules
│       │   │   │   ├── auth/         # Authentication components
│       │   │   │   ├── tasks/        # Task management components
│       │   │   │   ├── audit-log/    # Audit logging components
│       │   │   │   ├── layout/       # App layout components
│       │   │   │   └── shared/       # Shared components
│       │   │   ├── app.component.ts
│       │   │   ├── app.config.ts
│       │   │   └── app.routes.ts
│       │   ├── environments/    # Environment configuration
│       │   ├── styles.scss     # Global styles
│       │   └── main.ts         # Application entry point
│       ├── tsconfig.json       # TypeScript configuration
│       └── project.json       # NX project configuration
│
├── libs/
│   ├── data/                   # Shared data models/DTOs
│   │   ├── src/
│   │   │   ├── lib/
│   │   │   │   └── models/    # Shared TypeScript interfaces
│   │   │   └── index.ts       # Public API exports
│   │   ├── tsconfig.json      # TypeScript configuration
│   │   └── project.json      # NX project configuration
│   │
│   └── auth/                  # Shared authentication logic
│       ├── src/
│       │   ├── lib/
│       │   │   ├── decorators/ # Custom decorators
│       │   │   ├── guards/     # Access control guards
│       │   │   └── services/   # Common auth services
│       │   └── index.ts        # Public API exports
│       ├── tsconfig.json       # TypeScript configuration
│       └── project.json       # NX project configuration
│
├── package.json              # Dependencies and scripts
├── nx.json                   # NX workspace configuration
├── tsconfig.base.json        # Base TypeScript configuration
├── README.md                 # Project documentation
└── FOLDER_STRUCTURE.md       # This document
```

## Key Components

### Backend (NestJS)

1. **Config**
   - Database configuration (SQLite/PostgreSQL)
   - JWT authentication settings
   - Environment-specific settings

2. **Controllers**
   - Task controller - Manage task CRUD operations
   - Auth controller - Handle authentication
   - Audit-log controller - Access system logs

3. **Entities**
   - User - User model with role information
   - Organization - Hierarchical org structure
   - Task - Core task data model
   - AuditLog - System activity tracking

4. **Services**
   - Task service - Business logic for tasks
   - Auth service - Authentication and user management
   - AuditLog service - Logging and retrieval

5. **Guards**
   - JWT authentication
   - Role-based access control
   - Permission-based resource access

### Frontend (Angular)

1. **Core Module**
   - Authentication interceptors
   - Route guards
   - State management setup
   - API services

2. **State Management (NgRx)**
   - Auth state - User session and authentication
   - Task state - Task CRUD operations
   - Effects for API interactions
   - Selectors for state access

3. **Features**
   - Auth components - Login, registration
   - Task components - List, create, edit tasks
   - Audit Log components - View system activity
   - Layout components - Overall app structure

4. **Role Switcher**
   - Test different permission levels
   - Simulate different user roles

### Shared Libraries

1. **Data Library**
   - Shared interfaces for models
   - DTOs for API communication
   - Type definitions and enums

2. **Auth Library**
   - RBAC implementation
   - Permission decorators
   - Role guards
   - Audit logging service

## Database Schema

The application uses TypeORM with SQLite (development) or PostgreSQL (production) with the following schema:

1. **Users**
   - id: Primary key
   - email: Unique email address
   - password: Hashed password
   - firstName/lastName: User name
   - role: Enum (owner, admin, viewer)
   - organizationId: Foreign key to Organizations

2. **Organizations**
   - id: Primary key
   - name: Organization name
   - description: Optional description
   - parentOrgId: Self-referential FK for hierarchy

3. **Tasks**
   - id: Primary key
   - title: Task title
   - description: Task details
   - status: Enum (todo, in_progress, done)
   - category: Enum (work, personal)
   - priority: Numeric priority level
   - dueDate: Optional deadline
   - userId: Foreign key to Users
   - organizationId: Foreign key to Organizations

4. **AuditLogs**
   - id: Primary key
   - userId: Foreign key to Users
   - action: Enum (create, read, update, delete, login, logout)
   - resource: Resource type name
   - resourceId: Optional resource identifier
   - details: Additional information
   - createdAt: Timestamp