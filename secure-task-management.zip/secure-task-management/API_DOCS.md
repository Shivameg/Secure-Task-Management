# API Documentation

This document provides detailed information about the API endpoints available in the Secure Task Management System.

## Base URL

All API endpoints are prefixed with `/api`.

## Authentication

### Register a new user

**Endpoint:** `POST /api/auth/register`

**Description:** Creates a new user account

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "securepassword",
  "firstName": "John",
  "lastName": "Doe",
  "role": "viewer",
  "organizationId": 1
}
```

**Response (201 Created):**
```json
{
  "id": 2,
  "email": "user@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "role": "viewer",
  "organizationId": 1,
  "createdAt": "2023-05-01T10:30:00.000Z",
  "updatedAt": "2023-05-01T10:30:00.000Z"
}
```

### Login

**Endpoint:** `POST /api/auth/login`

**Description:** Authenticates a user and returns a JWT token

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "securepassword"
}
```

**Response (200 OK):**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 2,
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "viewer",
    "organizationId": 1
  }
}
```

### Logout

**Endpoint:** `POST /api/auth/logout`

**Description:** Invalidates the user session

**Headers:**
- `Authorization: Bearer <jwt_token>`

**Response (200 OK):**
```json
{
  "message": "Logged out successfully"
}
```

### Get Current User Profile

**Endpoint:** `POST /api/auth/me`

**Description:** Retrieves the current user's profile

**Headers:**
- `Authorization: Bearer <jwt_token>`

**Response (200 OK):**
```json
{
  "id": 2,
  "email": "user@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "role": "viewer",
  "organizationId": 1,
  "createdAt": "2023-05-01T10:30:00.000Z",
  "updatedAt": "2023-05-01T10:30:00.000Z"
}
```

## Task Management

### List Tasks

**Endpoint:** `GET /api/tasks`

**Description:** Retrieves a list of tasks accessible to the current user

**Headers:**
- `Authorization: Bearer <jwt_token>`

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "title": "Complete project documentation",
    "description": "Finish writing the technical specs",
    "status": "todo",
    "category": "work",
    "priority": 2,
    "dueDate": "2023-05-20T00:00:00.000Z",
    "userId": 2,
    "organizationId": 1,
    "createdAt": "2023-05-01T10:30:00.000Z",
    "updatedAt": "2023-05-01T10:30:00.000Z"
  },
  {
    "id": 2,
    "title": "Review pull requests",
    "description": "Review and merge pending PRs",
    "status": "in_progress",
    "category": "work",
    "priority": 3,
    "dueDate": null,
    "userId": 2,
    "organizationId": 1,
    "createdAt": "2023-05-01T11:45:00.000Z",
    "updatedAt": "2023-05-01T11:45:00.000Z"
  }
]
```

### Get Task by ID

**Endpoint:** `GET /api/tasks/:id`

**Description:** Retrieves a specific task by ID

**Headers:**
- `Authorization: Bearer <jwt_token>`

**Response (200 OK):**
```json
{
  "id": 1,
  "title": "Complete project documentation",
  "description": "Finish writing the technical specs",
  "status": "todo",
  "category": "work",
  "priority": 2,
  "dueDate": "2023-05-20T00:00:00.000Z",
  "userId": 2,
  "organizationId": 1,
  "createdAt": "2023-05-01T10:30:00.000Z",
  "updatedAt": "2023-05-01T10:30:00.000Z"
}
```

### Create Task

**Endpoint:** `POST /api/tasks`

**Description:** Creates a new task

**Headers:**
- `Authorization: Bearer <jwt_token>`

**Request Body:**
```json
{
  "title": "Implement new feature",
  "description": "Add user profile customization",
  "status": "todo",
  "category": "work",
  "priority": 2,
  "dueDate": "2023-06-15T00:00:00.000Z"
}
```

**Response (201 Created):**
```json
{
  "id": 3,
  "title": "Implement new feature",
  "description": "Add user profile customization",
  "status": "todo",
  "category": "work",
  "priority": 2,
  "dueDate": "2023-06-15T00:00:00.000Z",
  "userId": 2,
  "organizationId": 1,
  "createdAt": "2023-05-05T09:20:00.000Z",
  "updatedAt": "2023-05-05T09:20:00.000Z"
}
```

### Update Task

**Endpoint:** `PUT /api/tasks/:id`

**Description:** Updates an existing task

**Headers:**
- `Authorization: Bearer <jwt_token>`

**Request Body:**
```json
{
  "status": "in_progress",
  "priority": 3
}
```

**Response (200 OK):**
```json
{
  "id": 3,
  "title": "Implement new feature",
  "description": "Add user profile customization",
  "status": "in_progress",
  "category": "work",
  "priority": 3,
  "dueDate": "2023-06-15T00:00:00.000Z",
  "userId": 2,
  "organizationId": 1,
  "createdAt": "2023-05-05T09:20:00.000Z",
  "updatedAt": "2023-05-05T10:15:00.000Z"
}
```

### Delete Task

**Endpoint:** `DELETE /api/tasks/:id`

**Description:** Deletes a task

**Headers:**
- `Authorization: Bearer <jwt_token>`

**Response (204 No Content)**

## Audit Logs

### Get Audit Logs

**Endpoint:** `GET /api/audit-log`

**Description:** Retrieves audit logs (accessible only to Owner and Admin roles)

**Headers:**
- `Authorization: Bearer <jwt_token>`

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "userId": 1,
    "action": "create",
    "resource": "task",
    "resourceId": 1,
    "details": "Task created: Complete project documentation",
    "createdAt": "2023-05-01T10:30:00.000Z"
  },
  {
    "id": 2,
    "userId": 2,
    "action": "login",
    "resource": "auth",
    "resourceId": null,
    "details": "User login: user@example.com",
    "createdAt": "2023-05-01T10:25:00.000Z"
  },
  {
    "id": 3,
    "userId": 2,
    "action": "update",
    "resource": "task",
    "resourceId": 3,
    "details": "Task updated: Implement new feature",
    "createdAt": "2023-05-05T10:15:00.000Z"
  }
]
```

## Error Responses

### 401 Unauthorized
```json
{
  "statusCode": 401,
  "message": "Unauthorized",
  "error": "Unauthorized"
}
```

### 403 Forbidden
```json
{
  "statusCode": 403,
  "message": "User with role viewer does not have permission to delete task",
  "error": "Forbidden"
}
```

### 404 Not Found
```json
{
  "statusCode": 404,
  "message": "Task with ID 99 not found",
  "error": "Not Found"
}
```

### 409 Conflict
```json
{
  "statusCode": 409,
  "message": "Email already exists",
  "error": "Conflict"
}
```

## Access Control Rules

### Role Permissions

1. **Owner**
   - Can perform all operations
   - Can access all organizations
   - Can access audit logs

2. **Admin**
   - Can create, read, update, and delete tasks in their organization
   - Can view users in their organization
   - Can access audit logs for their organization
   - Cannot delete organizations

3. **Viewer**
   - Can read all tasks in their organization
   - Can create and update their own tasks
   - Cannot delete any tasks
   - Cannot access audit logs