# System Architecture and Model Interactions

This document explains the core models of the Secure Task Management System and how they interact with each other.

## Core Models and Their Relationships

### Entity Relationship Diagram

```
+---------------+       +---------------+       +---------------+
|     User      |       | Organization  |       |     Task      |
+---------------+       +---------------+       +---------------+
| id            |       | id            |       | id            |
| email         |       | name          |       | title         |
| password      |       | description   |       | description   |
| firstName     |       | parentOrgId   |<---+  | status        |
| lastName      |       +---------------+    |  | category      |
| role          |       | 1     ^    1  |    |  | priority      |
| organizationId|<----->| *     |    *  |    |  | dueDate       |
+---------------+       +-------+-------+----+  | userId        |<----+
| 1          ^  |                               | organizationId|<-+  |
| *          |  |                               +---------------+ |  |
+---------------+                               | *      *      | |  |
                                                +---------------+ |  |
                                                       ^          |  |
                                                       |          |  |
+---------------+                                       |          |  |
|   AuditLog    |                                       |          |  |
+---------------+                                       |          |  |
| id            |                                       |          |  |
| userId        |<-----------------------------------------+       |  |
| action        |                                                  |  |
| resource      |                                                  |  |
| resourceId    |                                                  |  |
| details       |                                                  |  |
| createdAt     |                                                  |  |
+---------------+                                                  |  |
                                                                   |  |
+---------------+                                                  |  |
|  Permission   |                                                  |  |
+---------------+                                                  |  |
| id            |                                                  |  |
| action        |                                                  |  |
| resource      |                                                  |  |
| roleId        |<-------------------------------------------------+  |
+---------------+                                                     |
                                                                      |
```

## Model Interactions

### User Model

The User model is central to the system's authorization and authentication framework:

- **Authentication**: Users provide email/password credentials to obtain a JWT token through the auth service
- **Authorization**: Each user has a role (Owner, Admin, Viewer) that determines their permissions
- **Organization Association**: Users belong to a specific organization which scopes their data access
- **Task Ownership**: Users create and own tasks
- **Audit Trail**: All user actions are recorded in the audit log

### Organization Model

Organizations provide hierarchical structure and data scoping:

- **Hierarchical Structure**: Organizations can have a parent-child relationship (two-level hierarchy)
- **User Grouping**: Organizations contain multiple users
- **Task Scoping**: Tasks are associated with specific organizations
- **Access Control**: A user's organization membership determines their data access scope

### Task Model

Tasks are the primary resource managed by the system:

- **Ownership**: Each task is created by and belongs to a specific user
- **Organizational Scope**: Tasks are associated with an organization
- **Status Tracking**: Tasks have a status (todo, in_progress, done)
- **Categorization**: Tasks can be categorized (work, personal)
- **Prioritization**: Tasks have priority levels for importance

### AuditLog Model

The AuditLog provides a comprehensive activity trail:

- **User Actions**: Records all significant user actions (create, read, update, delete, login, logout)
- **Resource Tracking**: Links actions to specific resources and resource IDs
- **Timestamps**: Records when actions occurred
- **Access Control**: Only accessible to users with Owner or Admin roles

## Service Interactions

### AuthService Interactions

```
┌─────────────┐     Login/Register     ┌─────────────┐
│    User     │<─────────────────────> │ AuthService │
└─────────────┘                        └──────┬──────┘
                                              │
                                              │ JWT Token
                                              ▼
┌─────────────┐   Authentication Check   ┌─────────────┐
│   Guards    │<─────────────────────────┤ JwtStrategy │
└─────────────┘                          └─────────────┘
```

### TaskService Authorization Flow

```
┌─────────────┐     CRUD Request     ┌──────────────┐
│    User     │────────────────────> │  Controller  │
└─────────────┘                      └──────┬───────┘
                                            │
                                            │ 
                                     ┌──────▼───────┐
                                     │  JWT Guard   │
                                     └──────┬───────┘
                                            │
                                            │
                                     ┌──────▼───────┐     ┌───────────────┐
                                     │Permission/Role├────>│  Role Check   │
                                     │    Guard      │     └───────────────┘
                                     └──────┬───────┘
                                            │                    ┌───────────────┐
                                            │                  ┌─┤Permission Check│
                                            │                  │ └───────────────┘
                                     ┌──────▼───────┐  Checks  │ ┌───────────────┐
                                     │ TaskService  ├──────────┼─┤ Org/User Check │
                                     └──────┬───────┘          │ └───────────────┘
                                            │                  │ ┌───────────────┐
                                            │                  └─┤ Resource Check │
                                            │                    └───────────────┘
                                     ┌──────▼───────┐
                                     │  Repository  │
                                     └──────┬───────┘
                                            │
                                            │
                                     ┌──────▼───────┐
                                     │   Database   │
                                     └──────────────┘
```

### Audit Logging Flow

```
┌─────────────┐     Action      ┌─────────────┐
│    User     │────────────────>│   Service   │
└─────────────┘                 └──────┬──────┘
                                       │
                                       │
                                ┌──────▼──────┐
                                │ AuditLogger │
                                └──────┬──────┘
                                       │
                                       │ Log Entry
                                       ▼
                                ┌─────────────┐
                                │  AuditLog   │
                                │ Repository  │
                                └─────────────┘
```

## Permission Logic Flow

```
┌─────────────┐     Request     ┌─────────────┐
│    User     │───────────────> │  Endpoint   │
└─────────────┘                 └──────┬──────┘
                                       │
                                       │
                                ┌──────▼──────┐
                                │ JWT Guard   │
                                └──────┬──────┘
                                       │ User Context
                                       │
                                ┌──────▼──────┐
                                │  Role Guard │
                                └──────┬──────┘
                                       │ Role Check
                                       │
                                ┌──────▼──────────┐
                                │ Permission Guard│
                                └──────┬──────────┘
                                       │ Permission Check
                                       │
                                ┌──────▼──────┐
                                │  Resource   │
                                │   Access    │
                                └─────────────┘
```

## Frontend State Management

```
┌─────────────┐     Action      ┌─────────────┐
│  Component  │────────────────>│   NgRx      │
└─────────────┘                 │  Actions    │
                                └──────┬──────┘
                                       │
                                       │
                                ┌──────▼──────┐     ┌─────────────┐
                                │ NgRx Effects│────>│ API Services│
                                └──────┬──────┘     └──────┬──────┘
                                       │                   │
                                       │                   │
                                ┌──────▼──────┐           │
                                │ NgRx Reducer│<──────────┘
                                └──────┬──────┘
                                       │ State Update
                                       │
                                ┌──────▼──────┐
                                │  NgRx Store │
                                └──────┬──────┘
                                       │ Selectors
                                       │
                                ┌──────▼──────┐
                                │  Component  │
                                └─────────────┘
```

## Key API Flows

### Task Creation Flow

1. Frontend Component initiates task creation via NgRx Action
2. NgRx Effect calls TaskService API
3. API Request hits JWT Guard for authentication
4. Request is passed to TaskController
5. Permission Guard checks if user has CREATE permission for TASK
6. TaskService creates task record with user's ID and organization ID
7. AuditLoggerService logs the creation action
8. Response returns to Effect
9. Effect dispatches success action
10. Reducer updates store with new task
11. Component UI updates via selector

### Role-Based Task Listing

1. Frontend Component initiates task list request via NgRx Action
2. NgRx Effect calls TaskService API
3. API Request hits JWT Guard for authentication
4. Request is passed to TaskController
5. Permission Guard checks if user has READ permission for TASK
6. TaskService applies role-based filtering:
   - Owner/Admin users get all tasks in their organization
   - Viewer users only get their own tasks
7. AuditLoggerService logs the read action
8. Filtered task list returns to Effect
9. Effect dispatches success action
10. Reducer updates store with tasks
11. Component UI updates via selector

### Audit Log Access

1. Frontend Component initiates audit log request via NgRx Action
2. NgRx Effect calls AuditLogService API
3. API Request hits JWT Guard for authentication
4. Request is passed to AuditLogController
5. Role Guard checks if user has Owner or Admin role
6. Permission Guard checks if user has READ permission for AUDIT_LOG
7. AuditLogService applies role-based filtering:
   - Owner users get all logs
   - Admin users get logs from their organization
8. Filtered log list returns to Effect
9. Effect dispatches success action
10. Reducer updates store with logs
11. Component UI updates via selector