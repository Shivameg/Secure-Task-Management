/**
 * This script creates a default organization and admin user
 * to get you started with the Secure Task Management System
 */
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');

// Connect to SQLite database
const db = new sqlite3.Database('./database.sqlite', (err) => {
  if (err) {
    console.error('Could not connect to database', err);
    return;
  }
  console.log('Connected to SQLite database');
});

// Create default organization
function createOrganization() {
  return new Promise((resolve, reject) => {
    const organization = {
      name: 'Default Organization',
      description: 'Default organization for testing',
      parentOrgId: null
    };

    db.run(
      `INSERT INTO organizations (name, description, parentOrgId)
       VALUES (?, ?, ?)`,
      [organization.name, organization.description, organization.parentOrgId],
      function(err) {
        if (err) {
          console.error('Error creating organization:', err);
          reject(err);
          return;
        }
        console.log(`Created organization with ID: ${this.lastID}`);
        resolve(this.lastID);
      }
    );
  });
}

// Create default admin user
async function createUser(organizationId) {
  try {
    // Hash the password
    const hashedPassword = await bcrypt.hash('admin123', 12);
    
    return new Promise((resolve, reject) => {
      const user = {
        email: 'admin@example.com',
        password: hashedPassword,
        firstName: 'Admin',
        lastName: 'User',
        role: 'owner',
        organizationId: organizationId
      };

      db.run(
        `INSERT INTO users (email, password, firstName, lastName, role, organizationId, createdAt, updatedAt) 
         VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`,
        [user.email, user.password, user.firstName, user.lastName, user.role, user.organizationId],
        function(err) {
          if (err) {
            console.error('Error creating user:', err);
            reject(err);
            return;
          }
          console.log(`Created user with ID: ${this.lastID}`);
          resolve(this.lastID);
        }
      );
    });
  } catch (error) {
    console.error('Error hashing password:', error);
    throw error;
  }
}

// Run the seed script
async function run() {
  try {
    const organizationId = await createOrganization();
    const userId = await createUser(organizationId);
    
    console.log('✅ Seed completed successfully!');
    console.log('Default login credentials:');
    console.log('Email: admin@example.com');
    console.log('Password: admin123');
    
    // Close the database connection
    db.close((err) => {
      if (err) {
        console.error('Error closing database:', err);
        return;
      }
      console.log('Database connection closed');
    });
  } catch (error) {
    console.error('Seed script failed:', error);
    db.close();
  }
}

// Execute the script
run();