import { ApplicationConfig, isDevMode } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { provideStoreDevtools } from '@ngrx/store-devtools';

import { routes } from './app.routes';
import { reducers } from './core/state';
import { authInterceptor } from './core/interceptors/auth.interceptor';

// Import effects
import { AuthEffects } from './core/state/auth/auth.effects';
import { TaskEffects } from './core/state/task/task.effects';
import { AuditLogEffects } from './core/state/audit-log/audit-log.effects';

export const appConfig: ApplicationConfig = {
  providers: [
    // Router
    provideRouter(routes),

    // HTTP
    provideHttpClient(withInterceptors([authInterceptor])),

    // NgRx store
    provideStore(reducers),

    // Effects - import explicitly
    provideEffects([
      AuthEffects,
      TaskEffects,
      AuditLogEffects
    ]),

    // DevTools
    isDevMode() ? provideStoreDevtools({
      maxAge: 25,
      logOnly: false,
      autoPause: true,
      trace: true,
      traceLimit: 75,
      connectInZone: true
    }) : []
  ]
};