import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, mergeMap, of } from 'rxjs';
import { AuditLogService } from '../../services/audit-log.service';
import * as AuditLogActions from './audit-log.actions';
import { Action } from '@ngrx/store';
import { AuditLog } from '@secure-task-management/data';
import { Observable } from 'rxjs';

@Injectable()
export class AuditLogEffects {
  private actions$ = inject(Actions);
  private auditLogService = inject(AuditLogService);

  loadAuditLogs$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuditLogActions.loadAuditLogs),
      mergeMap(() =>
        this.auditLogService.getAuditLogs().pipe(
          map(auditLogs => AuditLogActions.loadAuditLogsSuccess({ auditLogs: auditLogs as AuditLog[] })),
          catchError(error => of(AuditLogActions.loadAuditLogsFailure({ error })))
        )
      )
    ) as Observable<Action>;
  });
}