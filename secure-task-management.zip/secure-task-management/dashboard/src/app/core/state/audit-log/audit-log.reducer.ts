import { createReducer, on } from '@ngrx/store';
import { AuditLog } from '@secure-task-management/data';
import * as AuditLogActions from './audit-log.actions';

export interface AuditLogState {
  auditLogs: AuditLog[];
  filteredLogs: AuditLog[];
  filters: {
    userId?: number;
    resource?: string;
    action?: string;
  };
  loading: boolean;
  error: any;
}

export const initialState: AuditLogState = {
  auditLogs: [],
  filteredLogs: [],
  filters: {},
  loading: false,
  error: null
};

export const auditLogReducer = createReducer(
  initialState,
  
  // Load Audit Logs
  on(AuditLogActions.loadAuditLogs, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  
  on(AuditLogActions.loadAuditLogsSuccess, (state, { auditLogs }) => {
    // Filter out READ actions and keep only CREATE, UPDATE, DELETE
    const relevantLogs = auditLogs.filter(log =>
      log.action === 'create' || log.action === 'update' || log.action === 'delete' ||
      log.action === 'login' || log.action === 'logout'
    );

    // Apply any existing filters to the newly loaded logs
    const filteredLogs = applyFilters(relevantLogs, state.filters);

    return {
      ...state,
      auditLogs: relevantLogs,
      filteredLogs,
      loading: false
    };
  }),
  
  on(AuditLogActions.loadAuditLogsFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  })),
  
  // Filter Audit Logs
  on(AuditLogActions.filterAuditLogs, (state, { filters }) => {
    const newFilters = { ...state.filters, ...filters };
    const filteredLogs = applyFilters(state.auditLogs, newFilters);
    
    return {
      ...state,
      filters: newFilters,
      filteredLogs
    };
  }),
  
  on(AuditLogActions.clearAuditLogFilters, (state) => ({
    ...state,
    filters: {},
    filteredLogs: state.auditLogs
  }))
);

// Helper function to apply filters
function applyFilters(logs: AuditLog[], filters: { userId?: number; resource?: string; action?: string }): AuditLog[] {
  return logs.filter(log => {
    // Apply userId filter if present
    if (filters.userId !== undefined && log.userId !== filters.userId) {
      return false;
    }
    
    // Apply resource filter if present
    if (filters.resource && log.resource !== filters.resource) {
      return false;
    }
    
    // Apply action filter if present
    if (filters.action && log.action !== filters.action) {
      return false;
    }
    
    return true;
  });
}