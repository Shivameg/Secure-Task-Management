import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AuditLogState } from './audit-log.reducer';

export const selectAuditLogState = createFeatureSelector<AuditLogState>('auditLogs');

export const selectAllAuditLogs = createSelector(
  selectAuditLogState,
  (state: AuditLogState) => state.auditLogs
);

export const selectFilteredAuditLogs = createSelector(
  selectAuditLogState,
  (state: AuditLogState) => state.filteredLogs
);

export const selectAuditLogFilters = createSelector(
  selectAuditLogState,
  (state: AuditLogState) => state.filters
);

export const selectAuditLogLoading = createSelector(
  selectAuditLogState,
  (state: AuditLogState) => state.loading
);

export const selectAuditLogError = createSelector(
  selectAuditLogState,
  (state: AuditLogState) => state.error
);

export const selectAuditLogsByAction = (action: string) => createSelector(
  selectAllAuditLogs,
  (auditLogs) => auditLogs.filter(log => log.action === action)
);

export const selectAuditLogsByResource = (resource: string) => createSelector(
  selectAllAuditLogs,
  (auditLogs) => auditLogs.filter(log => log.resource === resource)
);

export const selectAuditLogsByUser = (userId: number) => createSelector(
  selectAllAuditLogs,
  (auditLogs) => auditLogs.filter(log => log.userId === userId)
);

export const selectUniqueActionTypes = createSelector(
  selectAllAuditLogs,
  (auditLogs) => [...new Set(auditLogs.map(log => log.action))]
);

export const selectUniqueResourceTypes = createSelector(
  selectAllAuditLogs,
  (auditLogs) => [...new Set(auditLogs.map(log => log.resource))]
);

export const selectUniqueUserIds = createSelector(
  selectAllAuditLogs,
  (auditLogs) => [...new Set(auditLogs.map(log => log.userId))]
);