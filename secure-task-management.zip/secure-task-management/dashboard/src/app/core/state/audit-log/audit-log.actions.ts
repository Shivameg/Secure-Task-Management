import { createAction, props } from '@ngrx/store';
import { AuditLog } from '@secure-task-management/data';

// Load Audit Logs
export const loadAuditLogs = createAction(
  '[AuditLog] Load Audit Logs'
);

export const loadAuditLogsSuccess = createAction(
  '[AuditLog] Load Audit Logs Success',
  props<{ auditLogs: AuditLog[] }>()
);

export const loadAuditLogsFailure = createAction(
  '[AuditLog] Load Audit Logs Failure',
  props<{ error: any }>()
);

// Filter Audit Logs
export const filterAuditLogs = createAction(
  '[AuditLog] Filter Audit Logs',
  props<{ filters: { userId?: number; resource?: string; action?: string } }>()
);

export const clearAuditLogFilters = createAction(
  '[AuditLog] Clear Audit Log Filters'
);