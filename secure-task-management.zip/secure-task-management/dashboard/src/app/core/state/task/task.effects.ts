import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, mergeMap, of } from 'rxjs';
import { TaskService } from '../../services/task.service';
import * as TaskActions from './task.actions';
import { Action } from '@ngrx/store';
import { Task } from '@secure-task-management/data';
import { Observable } from 'rxjs';

@Injectable()
export class TaskEffects {
  private actions$ = inject(Actions);
  private taskService = inject(TaskService);

  loadTasks$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(TaskActions.loadTasks),
      mergeMap(() =>
        this.taskService.getTasks().pipe(
          map(tasks => TaskActions.loadTasksSuccess({ tasks: tasks as Task[] })),
          catchError(error => of(TaskActions.loadTasksFailure({ error })))
        )
      )
    ) as Observable<Action>;
  });

  createTask$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(TaskActions.createTask),
      mergeMap(({ task }) =>
        this.taskService.createTask(task).pipe(
          map(createdTask => TaskActions.createTaskSuccess({ task: createdTask as Task })),
          catchError(error => of(TaskActions.createTaskFailure({ error })))
        )
      )
    ) as Observable<Action>;
  });

  updateTask$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(TaskActions.updateTask),
      mergeMap(({ id, task }) =>
        this.taskService.updateTask(id, task).pipe(
          map(updatedTask => TaskActions.updateTaskSuccess({ task: updatedTask as Task })),
          catchError(error => of(TaskActions.updateTaskFailure({ error })))
        )
      )
    ) as Observable<Action>;
  });

  deleteTask$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(TaskActions.deleteTask),
      mergeMap(({ id }) =>
        this.taskService.deleteTask(id).pipe(
          map(() => TaskActions.deleteTaskSuccess({ id })),
          catchError(error => of(TaskActions.deleteTaskFailure({ error })))
        )
      )
    ) as Observable<Action>;
  });
}