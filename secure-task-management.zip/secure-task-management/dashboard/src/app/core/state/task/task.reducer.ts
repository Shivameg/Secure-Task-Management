import { createReducer, on } from '@ngrx/store';
import { Task } from '@secure-task-management/data';
import * as TaskActions from './task.actions';

export interface TaskState {
  tasks: Task[];
  loading: boolean;
  loaded: boolean;
  error: any;
}

export const initialState: TaskState = {
  tasks: [],
  loading: false,
  loaded: false,
  error: null,
};

export const taskReducer = createReducer(
  initialState,
  
  // Load Tasks
  on(TaskActions.loadTasks, (state) => ({
    ...state,
    loading: true,
  })),
  
  on(TaskActions.loadTasksSuccess, (state, { tasks }) => ({
    ...state,
    tasks,
    loading: false,
    loaded: true,
  })),
  
  on(TaskActions.loadTasksFailure, (state, { error }) => ({
    ...state,
    error,
    loading: false,
  })),
  
  // Create Task
  on(TaskActions.createTask, (state) => ({
    ...state,
    loading: true,
  })),
  
  on(TaskActions.createTaskSuccess, (state, { task }) => ({
    ...state,
    tasks: [...state.tasks, task],
    loading: false,
  })),
  
  on(TaskActions.createTaskFailure, (state, { error }) => ({
    ...state,
    error,
    loading: false,
  })),
  
  // Update Task
  on(TaskActions.updateTask, (state) => ({
    ...state,
    loading: true,
  })),
  
  on(TaskActions.updateTaskSuccess, (state, { task }) => ({
    ...state,
    tasks: state.tasks.map(t => t.id === task.id ? task : t),
    loading: false,
  })),
  
  on(TaskActions.updateTaskFailure, (state, { error }) => ({
    ...state,
    error,
    loading: false,
  })),
  
  // Delete Task
  on(TaskActions.deleteTask, (state) => ({
    ...state,
    loading: true,
  })),
  
  on(TaskActions.deleteTaskSuccess, (state, { id }) => ({
    ...state,
    tasks: state.tasks.filter(task => task.id !== id),
    loading: false,
  })),
  
  on(TaskActions.deleteTaskFailure, (state, { error }) => ({
    ...state,
    error,
    loading: false,
  }))
);