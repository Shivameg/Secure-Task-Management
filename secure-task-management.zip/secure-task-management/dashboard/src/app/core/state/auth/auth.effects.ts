import { Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, exhaustMap, map, of, tap } from 'rxjs';
import * as AuthActions from './auth.actions';
import { AuthService } from '../../services/auth.service';
import { AuthTokenService } from '../../services/auth-token.service';
import { Action } from '@ngrx/store';
import { AuthResponse, User, UserRole } from '@secure-task-management/data';
import { Observable } from 'rxjs';

@Injectable()
export class AuthEffects {
  private actions$ = inject(Actions);
  private authService = inject(AuthService);
  private authTokenService = inject(AuthTokenService);
  private router = inject(Router);

  login$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuthActions.login),
      exhaustMap(({ credentials }) =>
        this.authService.login(credentials).pipe(
          map(authResponse => AuthActions.loginSuccess({ authResponse: authResponse as AuthResponse })),
          catchError(error => of(AuthActions.loginFailure({ error })))
        )
      )
    ) as Observable<Action>;
  });

  loginSuccess$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuthActions.loginSuccess),
      tap(({ authResponse }) => {
        // Persist auth data to localStorage
        this.authTokenService.saveToken(authResponse.accessToken);
        this.authTokenService.saveUser(authResponse.user);
        // Navigate to dashboard
        this.router.navigate(['/dashboard']);
      })
    ) as Observable<Action>;
  }, { dispatch: false });

  register$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuthActions.register),
      exhaustMap(({ user }) =>
        this.authService.register(user).pipe(
          map(createdUser => AuthActions.registerSuccess({ user: createdUser as User })),
          catchError(error => of(AuthActions.registerFailure({ error })))
        )
      )
    ) as Observable<Action>;
  });

  registerSuccess$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuthActions.registerSuccess),
      tap(() => this.router.navigate(['/login'], { queryParams: { registered: 'true' } }))
    ) as Observable<Action>;
  }, { dispatch: false });

  logout$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuthActions.logout),
      exhaustMap(() =>
        this.authService.logout().pipe(
          map(() => AuthActions.logoutSuccess()),
          catchError(error => of(AuthActions.logoutFailure({ error })))
        )
      )
    ) as Observable<Action>;
  });

  logoutSuccess$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuthActions.logoutSuccess),
      tap(() => {
        // Clear auth data from localStorage
        this.authTokenService.clearAuth();
        this.router.navigate(['/login']);
      })
    ) as Observable<Action>;
  }, { dispatch: false });

  getProfile$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuthActions.getProfile),
      exhaustMap(() =>
        this.authService.getProfile().pipe(
          map(user => AuthActions.getProfileSuccess({ user: user as User })),
          catchError(error => of(AuthActions.getProfileFailure({ error })))
        )
      )
    ) as Observable<Action>;
  });

  // Add a new effect to restore authentication state from localStorage
  initAuth$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuthActions.initAuth),
      map(() => {
        const token = this.authTokenService.getToken();
        const user = this.authTokenService.getUser();

        if (token && user) {
          return AuthActions.loginSuccess({
            authResponse: {
              accessToken: token,
              user: user
            }
          });
        }

        return AuthActions.noOp();
      })
    ) as Observable<Action>;
  });

  // Add effect to persist user role changes
  switchRole$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AuthActions.switchRole),
      tap(({ role }) => {
        const user = this.authTokenService.getUser();
        if (user) {
          const updatedUser = { ...user, role: role as UserRole };
          this.authTokenService.saveUser(updatedUser);
        }
      })
    ) as Observable<Action>;
  }, { dispatch: false });
}