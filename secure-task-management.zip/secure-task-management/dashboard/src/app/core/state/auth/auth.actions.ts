import { createAction, props } from '@ngrx/store';
import { User, UserLoginDto, CreateUserDto, AuthResponse } from '@secure-task-management/data';

// Initialize Authentication
export const initAuth = createAction(
  '[Auth] Initialize Authentication'
);

export const noOp = createAction(
  '[Auth] No Operation'
);

// Login
export const login = createAction(
  '[Auth] Login',
  props<{ credentials: UserLoginDto }>()
);

export const loginSuccess = createAction(
  '[Auth] Login Success',
  props<{ authResponse: AuthResponse }>()
);

export const loginFailure = createAction(
  '[Auth] Login Failure',
  props<{ error: any }>()
);

// Register
export const register = createAction(
  '[Auth] Register',
  props<{ user: CreateUserDto }>()
);

export const registerSuccess = createAction(
  '[Auth] Register Success',
  props<{ user: User }>()
);

export const registerFailure = createAction(
  '[Auth] Register Failure',
  props<{ error: any }>()
);

// Logout
export const logout = createAction(
  '[Auth] Logout'
);

export const logoutSuccess = createAction(
  '[Auth] Logout Success'
);

export const logoutFailure = createAction(
  '[Auth] Logout Failure',
  props<{ error: any }>()
);

// Get Profile
export const getProfile = createAction(
  '[Auth] Get Profile'
);

export const getProfileSuccess = createAction(
  '[Auth] Get Profile Success',
  props<{ user: User }>()
);

export const getProfileFailure = createAction(
  '[Auth] Get Profile Failure',
  props<{ error: any }>()
);

// Mock User Role Switch
export const switchRole = createAction(
  '[Auth] Switch Role',
  props<{ role: string }>()
);