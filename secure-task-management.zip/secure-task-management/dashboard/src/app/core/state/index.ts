import { ActionReducerMap } from '@ngrx/store';
import * as fromAuth from './auth/auth.reducer';
import * as fromTask from './task/task.reducer';
import * as fromAuditLog from './audit-log/audit-log.reducer';

export interface AppState {
  auth: fromAuth.AuthState;
  tasks: fromTask.TaskState;
  auditLogs: fromAuditLog.AuditLogState;
}

export const reducers: ActionReducerMap<AppState> = {
  auth: fromAuth.authReducer,
  tasks: fromTask.taskReducer,
  auditLogs: fromAuditLog.auditLogReducer,
};