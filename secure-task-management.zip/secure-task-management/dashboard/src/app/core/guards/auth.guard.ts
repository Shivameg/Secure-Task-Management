import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { of } from 'rxjs';
import { AuthTokenService } from '../services/auth-token.service';
import { AppState } from '../state';

export const authGuard = () => {
  const authTokenService = inject(AuthTokenService);
  const router = inject(Router);

  // Check if token exists in localStorage
  const isAuthenticated = authTokenService.isAuthenticated();

  if (isAuthenticated) {
    return of(true);
  }

  // Redirect to login page
  return of(router.createUrlTree(['/login']));
};