import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { EMPTY, catchError, first, mergeMap, throwError } from 'rxjs';
import { AuthTokenService } from '../services/auth-token.service';
import { AppState } from '../state';
import * as AuthActions from '../state/auth/auth.actions';

export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const authTokenService = inject(AuthTokenService);
  const store = inject(Store<AppState>);
  const router = inject(Router);

  // Get token from local storage instead of store
  const token = authTokenService.getToken();

  if (token) {
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  return next(request).pipe(
    catchError((error: HttpErrorResponse) => {
      // Handle 401 Unauthorized errors
      if (error.status === 401) {
        // Clear auth state
        authTokenService.clearAuth();
        store.dispatch(AuthActions.logoutSuccess());
        router.navigate(['/login']);
        return EMPTY;
      }

      return throwError(() => error);
    })
  );
};