import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AppState } from '../../../core/state';
import { loadTasks, deleteTask } from '../../../core/state/task/task.actions';
import { loadAuditLogs } from '../../../core/state/audit-log/audit-log.actions';
import { selectAllTasks, selectTasksLoading } from '../../../core/state/task/task.selectors';
import { selectUserRole } from '../../../core/state/auth/auth.selectors';
import { Task, TaskStatus, UserRole } from '@secure-task-management/data';
import { TaskFormComponent } from '../task-form/task-form.component';
import { RoleSwitcherComponent } from '../../shared/role-switcher/role-switcher.component';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, TaskFormComponent, RoleSwitcherComponent],
  template: `
    <div class="container mx-auto px-4 py-8">
      <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">My Tasks</h1>
        <app-role-switcher></app-role-switcher>
      </div>

      <app-task-form
        [taskToEdit]="selectedTask"
        (taskCreated)="refreshTasks()"
        (taskUpdated)="onTaskUpdated()"
      ></app-task-form>

      <div *ngIf="loading$ | async" class="flex justify-center mt-8">
        <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>

      <div *ngIf="!(loading$ | async) && (tasks$ | async)?.length === 0" class="mt-8 text-center text-gray-500">
        No tasks found. Create your first task above!
      </div>

      <div *ngIf="tasks$ | async as tasks" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        <div
          *ngFor="let task of tasks"
          class="bg-white rounded-lg shadow-md p-6 border-l-4"
          [ngClass]="{
            'border-red-500': task.status === 'todo',
            'border-yellow-500': task.status === 'in_progress',
            'border-green-500': task.status === 'done'
          }"
        >
          <div class="flex justify-between items-start mb-4">
            <h3 class="text-lg font-semibold">{{ task.title }}</h3>
            <span
              class="px-2 py-1 text-xs rounded-full"
              [ngClass]="{
                'bg-red-100 text-red-800': task.status === 'todo',
                'bg-yellow-100 text-yellow-800': task.status === 'in_progress',
                'bg-green-100 text-green-800': task.status === 'done'
              }"
            >
              {{ formatStatus(task.status) }}
            </span>
          </div>

          <p class="text-gray-600 mb-4">{{ task.description || 'No description' }}</p>

          <div class="flex justify-between items-center text-sm text-gray-500 mb-2">
            <span>{{ task.category }}</span>
            <span>Priority: {{ task.priority }}</span>
          </div>

          <div *ngIf="task.dueDate" class="text-sm text-gray-500">
            <span class="font-medium">Due Date:</span> {{ task.dueDate | date:'mediumDate' }}
          </div>

          <div class="mt-4 pt-4 border-t border-gray-100 flex justify-between">
            <button
              (click)="editTask(task)"
              class="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
            >
              Edit
            </button>

            <button
              (click)="onDeleteTask(task.id)"
              class="text-red-600 hover:text-red-800 text-sm font-medium"
              *ngIf="canDelete(task)"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TaskListComponent implements OnInit {
  tasks$: Observable<Task[]>;
  loading$: Observable<boolean>;
  userRole$: Observable<string | undefined>;
  selectedTask: Task | null = null;

  constructor(private store: Store<AppState>) {
    this.tasks$ = this.store.select(selectAllTasks);
    this.loading$ = this.store.select(selectTasksLoading);
    this.userRole$ = this.store.select(selectUserRole);
  }

  ngOnInit(): void {
    this.refreshTasks();
  }

  refreshTasks(): void {
    this.store.dispatch(loadTasks());
  }

  formatStatus(status: string): string {
    switch (status) {
      case TaskStatus.TODO:
        return 'To Do';
      case TaskStatus.IN_PROGRESS:
        return 'In Progress';
      case TaskStatus.DONE:
        return 'Done';
      default:
        return status;
    }
  }

  editTask(task: Task): void {
    this.selectedTask = task;
    // Scroll to the form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  onTaskUpdated(): void {
    this.selectedTask = null;
    this.refreshTasks();

    // Also refresh audit logs to show the update action
    this.store.dispatch(loadAuditLogs());
  }

  onDeleteTask(id: number): void {
    if (confirm('Are you sure you want to delete this task?')) {
      this.store.dispatch(deleteTask({ id }));

      // If currently editing this task, clear the form
      if (this.selectedTask && this.selectedTask.id === id) {
        this.selectedTask = null;
      }

      // Refresh audit logs to show the delete action
      setTimeout(() => {
        this.store.dispatch(loadAuditLogs());
      }, 500); // Small delay to ensure the delete completes first
    }
  }

  canDelete(task: Task): boolean {
    // Simple logic that will be replaced with actual permission checks
    let role: string | undefined;
    this.userRole$.subscribe(r => role = r).unsubscribe();

    return role === UserRole.OWNER || role === UserRole.ADMIN || task.userId === 1; // placeholder user ID
  }
}