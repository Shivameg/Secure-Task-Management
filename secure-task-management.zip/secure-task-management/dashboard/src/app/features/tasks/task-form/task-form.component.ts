import { Component, Output, EventEmitter, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { AppState } from '../../../core/state';
import { createTask, updateTask } from '../../../core/state/task/task.actions';
import { loadAuditLogs } from '../../../core/state/audit-log/audit-log.actions';
import { Task, TaskCategory, TaskStatus } from '@secure-task-management/data';

@Component({
  selector: 'app-task-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="bg-white rounded-lg shadow-md p-6">
      <h2 class="text-lg font-semibold mb-4">{{ editMode ? 'Edit Task' : 'Create New Task' }}</h2>
      
      <form [formGroup]="taskForm" (ngSubmit)="onSubmit()">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="col-span-2">
            <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Title</label>
            <input 
              type="text" 
              id="title" 
              formControlName="title"
              class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              [ngClass]="{'border-red-500': isFieldInvalid('title')}"
            >
            <div *ngIf="isFieldInvalid('title')" class="text-red-500 text-xs mt-1">
              Title is required
            </div>
          </div>
          
          <div class="col-span-2">
            <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea 
              id="description" 
              formControlName="description"
              rows="3"
              class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            ></textarea>
          </div>
          
          <div>
            <label for="status" class="block text-sm font-medium text-gray-700 mb-1">Status</label>
            <select 
              id="status" 
              formControlName="status"
              class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option [value]="statuses.TODO">To Do</option>
              <option [value]="statuses.IN_PROGRESS">In Progress</option>
              <option [value]="statuses.DONE">Done</option>
            </select>
          </div>
          
          <div>
            <label for="category" class="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select 
              id="category" 
              formControlName="category"
              class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option [value]="categories.WORK">Work</option>
              <option [value]="categories.PERSONAL">Personal</option>
            </select>
          </div>
          
          <div>
            <label for="priority" class="block text-sm font-medium text-gray-700 mb-1">Priority</label>
            <select 
              id="priority" 
              formControlName="priority"
              class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option [value]="1">Low</option>
              <option [value]="2">Medium</option>
              <option [value]="3">High</option>
            </select>
          </div>
          
          <div>
            <label for="dueDate" class="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
            <input 
              type="date" 
              id="dueDate" 
              formControlName="dueDate"
              class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
          </div>
        </div>
        
        <div class="mt-4 flex justify-end">
          <button
            type="submit"
            [disabled]="taskForm.invalid"
            class="px-4 py-2 bg-indigo-600 text-white rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            {{ editMode ? 'Update Task' : 'Create Task' }}
          </button>
        </div>
      </form>
    </div>
  `
})
export class TaskFormComponent implements OnChanges {
  @Input() taskToEdit: Task | null = null;
  @Output() taskCreated = new EventEmitter<void>();
  @Output() taskUpdated = new EventEmitter<void>();

  taskForm!: FormGroup;
  statuses = TaskStatus;
  categories = TaskCategory;
  editMode = false;

  constructor(
    private fb: FormBuilder,
    private store: Store<AppState>
  ) {
    this.initForm();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['taskToEdit'] && changes['taskToEdit'].currentValue) {
      this.editMode = true;
      const task = changes['taskToEdit'].currentValue;

      // Format date for the date input (YYYY-MM-DD)
      let formattedDueDate = null;
      if (task.dueDate) {
        const date = new Date(task.dueDate);
        formattedDueDate = date.toISOString().split('T')[0];
      }

      this.taskForm.patchValue({
        title: task.title,
        description: task.description || '',
        status: task.status,
        category: task.category,
        priority: task.priority,
        dueDate: formattedDueDate
      });
    } else if (changes['taskToEdit'] && !changes['taskToEdit'].currentValue) {
      this.editMode = false;
      this.resetForm();
    }
  }

  private initForm(): void {
    this.taskForm = this.fb.group({
      title: ['', Validators.required],
      description: [''],
      status: [TaskStatus.TODO],
      category: [TaskCategory.WORK],
      priority: [1],
      dueDate: [null]
    });
  }

  private resetForm(): void {
    this.taskForm.reset({
      status: TaskStatus.TODO,
      category: TaskCategory.WORK,
      priority: 1
    });
  }

  onSubmit(): void {
    if (this.taskForm.valid) {
      if (this.editMode && this.taskToEdit) {
        this.store.dispatch(updateTask({
          id: this.taskToEdit.id,
          task: this.taskForm.value
        }));

        // Refresh audit logs after update
        setTimeout(() => {
          this.store.dispatch(loadAuditLogs());
        }, 500);

        this.taskUpdated.emit();
      } else {
        this.store.dispatch(createTask({ task: this.taskForm.value }));

        // Refresh audit logs after create
        setTimeout(() => {
          this.store.dispatch(loadAuditLogs());
        }, 500);

        this.resetForm();
        this.taskCreated.emit();
      }
    } else {
      this.taskForm.markAllAsTouched();
    }
  }
  
  isFieldInvalid(field: string): boolean {
    const formControl = this.taskForm.get(field);
    return formControl ? formControl.invalid && (formControl.dirty || formControl.touched) : false;
  }
}