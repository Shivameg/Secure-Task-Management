import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Store } from '@ngrx/store';
import { map } from 'rxjs/operators';
import { AppState } from '../../../core/state';
import { selectUser } from '../../../core/state/auth/auth.selectors';
import { logout } from '../../../core/state/auth/auth.actions';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="min-h-screen bg-gray-50">
      <nav class="bg-white shadow-sm border-b">
        <div class="container mx-auto px-4">
          <div class="flex justify-between h-16">
            <div class="flex">
              <div class="flex-shrink-0 flex items-center">
                <span class="text-lg font-bold text-indigo-600">Task Manager</span>
              </div>
              <div class="ml-6 flex space-x-8">
                <a routerLink="/dashboard" routerLinkActive="border-indigo-500 text-gray-900" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                  Dashboard
                </a>
                <a routerLink="/tasks" routerLinkActive="border-indigo-500 text-gray-900" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                  Tasks
                </a>
                <a *ngIf="isAdmin$ | async" routerLink="/audit-log" routerLinkActive="border-indigo-500 text-gray-900" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                  Audit Log
                </a>
              </div>
            </div>
            <div class="ml-6 flex items-center">
              <div *ngIf="user$ | async as user" class="flex items-center">
                <span class="text-sm text-gray-500 mr-4">
                  Welcome, {{ getUserName(user) }}!
                </span>
                <button 
                  (click)="onLogout()"
                  class="ml-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main class="py-6">
        <router-outlet></router-outlet>
      </main>
    </div>
  `
})
export class MainLayoutComponent {
  user$: any;
  isAdmin$: any;

  constructor(private store: Store<AppState>) {
    this.user$ = this.store.select(selectUser);
    this.isAdmin$ = this.store.select(selectUser).pipe(
      map(user => user?.role === 'owner' || user?.role === 'admin')
    );
  }

  // Helper method to safely access user properties
  getUserName(user: any): string {
    return user && typeof user === 'object' && 'firstName' in user
      ? user.firstName
      : 'User';
  }

  onLogout(): void {
    this.store.dispatch(logout());
  }
}