import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { Observable, Subject, catchError, combineLatest, map, of, takeUntil } from 'rxjs';
import { RouterLink } from '@angular/router';

import { AppState } from '../../core/state';
import { Task, TaskStatus, TaskCategory } from '@secure-task-management/data';
import * as TaskActions from '../../core/state/task/task.actions';
import * as AuditLogActions from '../../core/state/audit-log/audit-log.actions';
import { selectAllTasks, selectTasksLoading } from '../../core/state/task/task.selectors';
import { selectAllAuditLogs, selectAuditLogLoading } from '../../core/state/audit-log/audit-log.selectors';
import { RoleSwitcherComponent } from '../shared/role-switcher/role-switcher.component';
import { selectUser } from '../../core/state/auth/auth.selectors';

interface TaskStatusStat {
  status: TaskStatus;
  count: number;
  percentage: number;
}

interface TaskPriorityStat {
  priority: 'high' | 'medium' | 'low';
  count: number;
  percentage: number;
}

interface TaskCategoryStat {
  category: TaskCategory;
  count: number;
  percentage: number;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, RoleSwitcherComponent],
  template: `
    <div class="container mx-auto px-4 py-8">
      <div class="flex justify-between items-center mb-8">
        <h1 class="text-2xl font-bold">Dashboard</h1>
        <app-role-switcher></app-role-switcher>
      </div>
      
      <!-- Loading Spinner -->
      <div *ngIf="loading$ | async" class="flex justify-center my-8">
        <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
      
      <!-- Dashboard content -->
      <ng-container *ngIf="!(loading$ | async)">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          <!-- Tasks by Status -->
          <ng-container *ngIf="tasksByStatus$ | async as statusStats">
            <div class="bg-white rounded-lg shadow p-6">
              <h2 class="text-lg font-semibold mb-4">Tasks by Status</h2>
              <div class="space-y-4">
                <div *ngFor="let stat of statusStats" class="flex justify-between items-center">
                  <div class="flex items-center">
                    <span 
                      class="w-3 h-3 rounded-full mr-2"
                      [ngClass]="{
                        'bg-gray-400': stat.status === 'todo',
                        'bg-blue-400': stat.status === 'in_progress',
                        'bg-green-400': stat.status === 'done'
                      }"
                    ></span>
                    <span class="capitalize">{{ stat.status.replace('_', ' ') }}</span>
                  </div>
                  <div class="flex items-center">
                    <span class="font-medium">{{ stat.count }}</span>
                    <div class="ml-2 h-2 bg-gray-200 rounded-full w-24">
                      <div 
                        class="h-full rounded-full"
                        [ngClass]="{
                          'bg-gray-400': stat.status === 'todo',
                          'bg-blue-400': stat.status === 'in_progress',
                          'bg-green-400': stat.status === 'done'
                        }"
                        [style.width.%]="stat.percentage"
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="mt-4">
                <a 
                  routerLink="/tasks" 
                  class="text-sm text-indigo-600 hover:text-indigo-800 font-medium flex items-center"
                >
                  View all tasks
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd" />
                  </svg>
                </a>
              </div>
            </div>
          </ng-container>

          <!-- Tasks by Priority -->
          <ng-container *ngIf="tasksByPriority$ | async as priorityStats">
            <div class="bg-white rounded-lg shadow p-6">
              <h2 class="text-lg font-semibold mb-4">Tasks by Priority</h2>
              <div class="space-y-4">
                <div *ngFor="let stat of priorityStats" class="flex justify-between items-center">
                  <div class="flex items-center">
                    <span 
                      class="w-3 h-3 rounded-full mr-2"
                      [ngClass]="{
                        'bg-red-400': stat.priority === 'high',
                        'bg-yellow-400': stat.priority === 'medium',
                        'bg-green-400': stat.priority === 'low'
                      }"
                    ></span>
                    <span class="capitalize">{{ stat.priority }}</span>
                  </div>
                  <div class="flex items-center">
                    <span class="font-medium">{{ stat.count }}</span>
                    <div class="ml-2 h-2 bg-gray-200 rounded-full w-24">
                      <div 
                        class="h-full rounded-full"
                        [ngClass]="{
                          'bg-red-400': stat.priority === 'high',
                          'bg-yellow-400': stat.priority === 'medium',
                          'bg-green-400': stat.priority === 'low'
                        }"
                        [style.width.%]="stat.percentage"
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="mt-4">
                <a 
                  routerLink="/tasks" 
                  class="text-sm text-indigo-600 hover:text-indigo-800 font-medium flex items-center"
                >
                  View all tasks
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd" />
                  </svg>
                </a>
              </div>
            </div>
          </ng-container>

          <!-- Tasks by Category -->
          <ng-container *ngIf="tasksByCategory$ | async as categoryStats">
            <div class="bg-white rounded-lg shadow p-6">
              <h2 class="text-lg font-semibold mb-4">Tasks by Category</h2>
              <div class="space-y-4">
                <div *ngFor="let stat of categoryStats" class="flex justify-between items-center">
                  <div class="flex items-center">
                    <span 
                      class="w-3 h-3 rounded-full mr-2"
                      [ngClass]="{
                        'bg-indigo-400': stat.category === taskCategoryEnum.WORK,
                        'bg-pink-400': stat.category === taskCategoryEnum.PERSONAL
                      }"
                    ></span>
                    <span class="capitalize">{{ stat.category.toLowerCase() }}</span>
                  </div>
                  <div class="flex items-center">
                    <span class="font-medium">{{ stat.count }}</span>
                    <div class="ml-2 h-2 bg-gray-200 rounded-full w-24">
                      <div 
                        class="h-full rounded-full"
                        [ngClass]="{
                          'bg-indigo-400': stat.category === taskCategoryEnum.WORK,
                          'bg-pink-400': stat.category === taskCategoryEnum.PERSONAL
                        }"
                        [style.width.%]="stat.percentage"
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="mt-4">
                <a 
                  routerLink="/tasks" 
                  class="text-sm text-indigo-600 hover:text-indigo-800 font-medium flex items-center"
                >
                  View all tasks
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd" />
                  </svg>
                </a>
              </div>
            </div>
          </ng-container>
          
          <!-- Recent Activity -->
          <div class="bg-white rounded-lg shadow p-6 md:col-span-2 lg:col-span-3">
            <h2 class="text-lg font-semibold mb-4">Recent Activity</h2>
            
            <ng-container *ngIf="recentLogs$ | async as logs">
              <div *ngIf="logs.length === 0" class="text-center text-gray-500 py-4">
                No recent activity
              </div>
              <div *ngIf="logs.length > 0" class="overflow-hidden">
                <ul class="divide-y divide-gray-200">
                  <li *ngFor="let log of logs" class="py-4">
                    <div class="flex space-x-3">
                      <div class="flex-1 space-y-1">
                        <div class="flex items-center justify-between">
                          <h3 class="text-sm font-medium">
                            <span 
                              class="px-2 py-1 text-xs font-semibold rounded-full mr-2"
                              [ngClass]="{
                                'bg-green-100 text-green-800': log.action === 'create',
                                'bg-yellow-100 text-yellow-800': log.action === 'update',
                                'bg-red-100 text-red-800': log.action === 'delete',
                                'bg-purple-100 text-purple-800': log.action === 'login' || log.action === 'logout'
                              }"
                            >
                              {{ log.action | uppercase }}
                            </span>
                            <span>{{ log.resource }}</span>
                            <span *ngIf="log.resourceId" class="text-xs text-gray-400">#{{ log.resourceId }}</span>
                          </h3>
                          <p class="text-sm text-gray-500">{{ log.createdAt | date:'medium' }}</p>
                        </div>
                        <p class="text-sm text-gray-500">{{ log.details }}</p>
                        <p class="text-xs text-gray-400">
                          <span *ngIf="log.user?.firstName">By: {{ log.user?.firstName }} {{ log.user?.lastName }}</span>
                          <span *ngIf="!log.user">User ID: {{ log.userId }}</span>
                        </p>
                      </div>
                    </div>
                  </li>
                </ul>
                <div class="mt-4">
                  <a 
                    routerLink="/audit-log" 
                    class="text-sm text-indigo-600 hover:text-indigo-800 font-medium flex items-center"
                  >
                    View all activities
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fill-rule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                  </a>
                </div>
              </div>
            </ng-container>
          </div>
        </div>
      </ng-container>

      <!-- No duplicate audit logs section needed since it's already in the Recent Activity section above -->
    </div>
  `
})
export class DashboardComponent implements OnInit, OnDestroy {
  tasks$: Observable<Task[]>;
  loading$: Observable<boolean>;
  
  tasksByStatus$: Observable<TaskStatusStat[]>;
  tasksByPriority$: Observable<TaskPriorityStat[]>;
  tasksByCategory$: Observable<TaskCategoryStat[]>;
  recentLogs$: Observable<any[]>;
  
  // Expose the enum to the template
  taskCategoryEnum = TaskCategory;
  
  private destroy$ = new Subject<void>();
  
  constructor(private store: Store<AppState>) {
    this.tasks$ = this.store.select(selectAllTasks).pipe(
      takeUntil(this.destroy$)
    );

    // Initialize recentLogs$ with proper error handling
    this.recentLogs$ = this.store.select(selectAllAuditLogs).pipe(
      map(logs => logs?.slice(0, 5) || []),
      catchError(() => of([])),
      takeUntil(this.destroy$)
    );

    // Combine loading states
    this.loading$ = combineLatest([
      this.store.select(selectTasksLoading),
      this.store.select(selectAuditLogLoading)
    ]).pipe(
      map(([tasksLoading, logsLoading]) => tasksLoading || logsLoading),
      takeUntil(this.destroy$)
    );
    
    // Calculate task statistics
    this.tasksByStatus$ = this.tasks$.pipe(
      map(tasks => {
        const statusCounts: Record<TaskStatus, number> = {
          'todo': 0,
          'in_progress': 0,
          'done': 0
        };
        
        // Count tasks by status
        tasks?.forEach(task => {
          if (task && statusCounts[task.status] !== undefined) {
            statusCounts[task.status]++;
          } else if (task) {
            statusCounts['todo']++;
          }
        });
        
        const total = tasks?.length || 1; // Avoid division by zero
        
        // Convert to array with percentages
        return Object.entries(statusCounts).map(([status, count]) => ({
          status: status as TaskStatus,
          count,
          percentage: (count / total) * 100
        }));
      }),
      catchError(error => {
        console.error('Error calculating task status statistics', error);
        return of([]);
      }),
      takeUntil(this.destroy$)
    );
    
    this.tasksByPriority$ = this.tasks$.pipe(
      map(tasks => {
        const priorityCounts: Record<'high' | 'medium' | 'low', number> = {
          'high': 0,
          'medium': 0,
          'low': 0
        };
        
        // Count tasks by priority
        tasks?.forEach(task => {
          if (task) {
            const priority = task.priority === 3 ? 'high' : 
                            task.priority === 2 ? 'medium' : 'low';
            
            priorityCounts[priority]++;
          }
        });
        
        const total = tasks?.length || 1; // Avoid division by zero
        
        // Convert to array with percentages
        return Object.entries(priorityCounts).map(([priority, count]) => ({
          priority: priority as 'high' | 'medium' | 'low',
          count,
          percentage: (count / total) * 100
        }));
      }),
      catchError(error => {
        console.error('Error calculating task priority statistics', error);
        return of([]);
      }),
      takeUntil(this.destroy$)
    );
    
    this.tasksByCategory$ = this.tasks$.pipe(
      map(tasks => {
        const categoryCounts: Record<TaskCategory, number> = {
          [TaskCategory.WORK]: 0,
          [TaskCategory.PERSONAL]: 0
        };
        
        // Count tasks by category with null check
        tasks?.forEach(task => {
          if (task?.category && categoryCounts[task.category] !== undefined) {
            categoryCounts[task.category]++;
          } else if (task) {
            categoryCounts[TaskCategory.WORK]++; // Default to WORK if category is invalid
          }
        });
        
        const total = tasks?.length || 1;
        
        return Object.entries(categoryCounts).map(([category, count]) => ({
          category: category as TaskCategory,
          count,
          percentage: (count / total) * 100
        }));
      }),
      catchError(error => {
        console.error('Error calculating task category statistics', error);
        return of([]);
      }),
      takeUntil(this.destroy$)
    );
  }
  
  ngOnInit(): void {
    // Load data
    this.store.dispatch(TaskActions.loadTasks());
    this.store.dispatch(AuditLogActions.loadAuditLogs());
  }
  
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}