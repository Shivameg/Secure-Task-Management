import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { AppState } from '../../../core/state';
import { register } from '../../../core/state/auth/auth.actions';
import { selectAuthError, selectAuthLoading } from '../../../core/state/auth/auth.selectors';
import { RouterLink } from '@angular/router';
import { UserRole } from '@secure-task-management/data';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="flex min-h-screen items-center justify-center bg-gray-50">
      <div class="w-full max-w-md p-8 space-y-8 bg-white rounded-lg shadow-md">
        <div class="text-center">
          <h1 class="text-2xl font-bold">Create an account</h1>
          <p class="mt-2 text-gray-600">Enter your information below</p>
        </div>
        
        <form [formGroup]="registerForm" (ngSubmit)="onSubmit()" class="mt-8 space-y-6">
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label for="firstName" class="block text-sm font-medium text-gray-700">First Name</label>
              <input 
                id="firstName" 
                formControlName="firstName" 
                type="text" 
                class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                [ngClass]="{'border-red-500': isFieldInvalid('firstName')}"
              >
              <div *ngIf="isFieldInvalid('firstName')" class="text-red-500 text-xs mt-1">
                First name is required
              </div>
            </div>
            
            <div>
              <label for="lastName" class="block text-sm font-medium text-gray-700">Last Name</label>
              <input 
                id="lastName" 
                formControlName="lastName" 
                type="text" 
                class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                [ngClass]="{'border-red-500': isFieldInvalid('lastName')}"
              >
              <div *ngIf="isFieldInvalid('lastName')" class="text-red-500 text-xs mt-1">
                Last name is required
              </div>
            </div>
          </div>
          
          <div>
            <label for="email" class="block text-sm font-medium text-gray-700">Email address</label>
            <input 
              id="email" 
              formControlName="email" 
              type="email" 
              class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              [ngClass]="{'border-red-500': isFieldInvalid('email')}"
            >
            <div *ngIf="isFieldInvalid('email')" class="text-red-500 text-xs mt-1">
              Email is required and must be valid
            </div>
          </div>
          
          <div>
            <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
            <input 
              id="password" 
              formControlName="password" 
              type="password" 
              class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              [ngClass]="{'border-red-500': isFieldInvalid('password')}"
            >
            <div *ngIf="isFieldInvalid('password')" class="text-red-500 text-xs mt-1">
              Password is required (min 6 characters)
            </div>
          </div>
          
          <div>
            <label for="role" class="block text-sm font-medium text-gray-700">Role</label>
            <select 
              id="role" 
              formControlName="role" 
              class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option [value]="roles.OWNER">Owner</option>
              <option [value]="roles.ADMIN">Admin</option>
              <option [value]="roles.VIEWER">Viewer</option>
            </select>
          </div>
          
          <div>
            <label for="organizationId" class="block text-sm font-medium text-gray-700">Organization ID</label>
            <input 
              id="organizationId" 
              formControlName="organizationId" 
              type="number" 
              class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              [ngClass]="{'border-red-500': isFieldInvalid('organizationId')}"
            >
            <div *ngIf="isFieldInvalid('organizationId')" class="text-red-500 text-xs mt-1">
              Organization ID is required
            </div>
          </div>
          
          <div *ngIf="error$ | async as error" class="text-red-500 text-sm">
            {{ getErrorMessage(error) }}
          </div>
          
          <div>
            <button 
              type="submit" 
              [disabled]="registerForm.invalid || (loading$ | async)"
              class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
            >
              <span *ngIf="loading$ | async">Creating account...</span>
              <span *ngIf="!(loading$ | async)">Create account</span>
            </button>
          </div>
          
          <div class="text-center text-sm">
            <span class="text-gray-600">Already have an account?</span>
            <a routerLink="/login" class="font-medium text-indigo-600 hover:text-indigo-500 ml-1">Sign in</a>
          </div>
        </form>
      </div>
    </div>
  `
})
export class RegisterComponent {
  registerForm: FormGroup;
  loading$: any;
  error$: any;
  roles = UserRole;

  constructor(
    private fb: FormBuilder,
    private store: Store<AppState>
  ) {
    this.registerForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: [UserRole.VIEWER, Validators.required],
      organizationId: [1, Validators.required]
    });
    this.loading$ = this.store.select(selectAuthLoading);
    this.error$ = this.store.select(selectAuthError);
  }

  // Helper method to safely access error message
  getErrorMessage(error: any): string {
    return error && typeof error === 'object' && 'message' in error
      ? error.message
      : 'Registration failed. Please try again.';
  }

  onSubmit(): void {
    if (this.registerForm.valid) {
      this.store.dispatch(register({ user: this.registerForm.value }));
    } else {
      this.registerForm.markAllAsTouched();
    }
  }

  isFieldInvalid(field: string): boolean {
    const formControl = this.registerForm.get(field);
    return formControl ? formControl.invalid && (formControl.dirty || formControl.touched) : false;
  }
}