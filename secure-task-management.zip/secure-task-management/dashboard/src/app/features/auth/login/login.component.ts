import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { AppState } from '../../../core/state';
import { login } from '../../../core/state/auth/auth.actions';
import { selectAuthError, selectAuthLoading } from '../../../core/state/auth/auth.selectors';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="flex min-h-screen items-center justify-center bg-gray-50">
      <div class="w-full max-w-md p-8 space-y-8 bg-white rounded-lg shadow-md">
        <div class="text-center">
          <h1 class="text-2xl font-bold">Sign in to your account</h1>
          <p class="mt-2 text-gray-600">Enter your credentials below</p>
        </div>
        
        <form [formGroup]="loginForm" (ngSubmit)="onSubmit()" class="mt-8 space-y-6">
          <div>
            <label for="email" class="block text-sm font-medium text-gray-700">Email address</label>
            <input 
              id="email" 
              formControlName="email" 
              type="email" 
              class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              [ngClass]="{'border-red-500': isFieldInvalid('email')}"
            >
            <div *ngIf="isFieldInvalid('email')" class="text-red-500 text-xs mt-1">
              Email is required and must be valid
            </div>
          </div>
          
          <div>
            <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
            <input 
              id="password" 
              formControlName="password" 
              type="password" 
              class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              [ngClass]="{'border-red-500': isFieldInvalid('password')}"
            >
            <div *ngIf="isFieldInvalid('password')" class="text-red-500 text-xs mt-1">
              Password is required (min 6 characters)
            </div>
          </div>
          
          <div *ngIf="error$ | async as error" class="text-red-500 text-sm">
            {{ getErrorMessage(error) }}
          </div>
          
          <div>
            <button 
              type="submit" 
              [disabled]="loginForm.invalid || (loading$ | async)"
              class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
            >
              <span *ngIf="loading$ | async">Signing in...</span>
              <span *ngIf="!(loading$ | async)">Sign in</span>
            </button>
          </div>
          
          <div class="text-center text-sm">
            <span class="text-gray-600">Don't have an account?</span>
            <a routerLink="/register" class="font-medium text-indigo-600 hover:text-indigo-500 ml-1">Sign up</a>
          </div>
        </form>
      </div>
    </div>
  `
})
export class LoginComponent {
  loginForm: FormGroup;
  loading$: any;
  error$: any;

  constructor(
    private fb: FormBuilder,
    private store: Store<AppState>
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
    this.loading$ = this.store.select(selectAuthLoading);
    this.error$ = this.store.select(selectAuthError);
  }

  // Helper method to safely access error message
  getErrorMessage(error: any): string {
    return error && typeof error === 'object' && 'message' in error
      ? error.message
      : 'Invalid credentials';
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      console.log('Dispatching login action with credentials:', this.loginForm.value);
      this.store.dispatch(login({ credentials: this.loginForm.value }));
    } else {
      this.loginForm.markAllAsTouched();
    }
  }

  isFieldInvalid(field: string): boolean {
    const formControl = this.loginForm.get(field);
    return formControl ? formControl.invalid && (formControl.dirty || formControl.touched) : false;
  }
}