import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { AppState } from '../../../core/state';
import { switchRole } from '../../../core/state/auth/auth.actions';
import { selectUserRole } from '../../../core/state/auth/auth.selectors';
import { UserRole } from '@secure-task-management/data';

@Component({
  selector: 'app-role-switcher',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="bg-white rounded-lg shadow-sm border p-3">
      <div class="text-sm font-medium text-gray-500 mb-2">Test Different Roles:</div>
      <div class="flex space-x-2">
        <button 
          *ngFor="let role of roles"
          (click)="switchUserRole(role)"
          class="px-3 py-1 rounded-md text-sm font-medium"
          [ngClass]="(currentRole$ | async) === role 
            ? 'bg-indigo-600 text-white' 
            : 'bg-gray-100 hover:bg-gray-200 text-gray-800'"
        >
          {{ formatRole(role) }}
        </button>
      </div>
    </div>
  `
})
export class RoleSwitcherComponent {
  roles = [UserRole.OWNER, UserRole.ADMIN, UserRole.VIEWER];
  currentRole$: any;

  constructor(private store: Store<AppState>) {
    this.currentRole$ = this.store.select(selectUserRole);
  }

  formatRole(role: string): string {
    return role.charAt(0).toUpperCase() + role.slice(1);
  }

  switchUserRole(role: string): void {
    this.store.dispatch(switchRole({ role }));
  }
}