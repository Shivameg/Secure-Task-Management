import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable, Subject, takeUntil } from 'rxjs';
import { AuditLog } from '@secure-task-management/data';
import { AppState } from '../../../core/state';
import * as AuditLogActions from '../../../core/state/audit-log/audit-log.actions';
import {
  selectFilteredAuditLogs,
  selectAuditLogLoading,
  selectAuditLogError,
  selectUniqueActionTypes,
  selectUniqueResourceTypes,
  selectUniqueUserIds
} from '../../../core/state/audit-log/audit-log.selectors';

@Component({
  selector: 'app-audit-log-list',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-2xl font-bold mb-6">Audit Logs</h1>

      <!-- Filters -->
      <div class="bg-white p-4 rounded-lg shadow mb-6">
        <h2 class="text-lg font-semibold mb-4">Filters</h2>
        <form [formGroup]="filterForm" class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <!-- Action Filter -->
          <div>
            <label for="action" class="block text-sm font-medium text-gray-700 mb-1">Action</label>
            <select
              id="action"
              formControlName="action"
              class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            >
              <option value="">All Actions</option>
              <option *ngFor="let action of actionTypes$ | async" [value]="action">
                {{ action | titlecase }}
              </option>
            </select>
          </div>

          <!-- Resource Filter -->
          <div>
            <label for="resource" class="block text-sm font-medium text-gray-700 mb-1">Resource</label>
            <select
              id="resource"
              formControlName="resource"
              class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            >
              <option value="">All Resources</option>
              <option *ngFor="let resource of resourceTypes$ | async" [value]="resource">
                {{ resource | titlecase }}
              </option>
            </select>
          </div>

          <!-- User Filter -->
          <div>
            <label for="userId" class="block text-sm font-medium text-gray-700 mb-1">User ID</label>
            <select
              id="userId"
              formControlName="userId"
              class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            >
              <option value="">All Users</option>
              <option *ngFor="let userId of userIds$ | async" [value]="userId">
                {{ userId }}
              </option>
            </select>
          </div>
        </form>

        <div class="mt-4 flex justify-end">
          <button
            (click)="clearFilters()"
            class="px-4 py-2 mr-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Clear Filters
          </button>
        </div>
      </div>

      <!-- Error Message -->
      <div *ngIf="error$ | async as error" class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
        <p>{{ error.message || 'An error occurred while loading audit logs.' }}</p>
      </div>

      <!-- Loading Spinner -->
      <div *ngIf="loading$ | async" class="flex justify-center mt-8">
        <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>

      <!-- Empty State -->
      <ng-container *ngIf="auditLogs$ | async as logs">
        <div *ngIf="!(loading$ | async) && logs.length === 0" class="mt-8 text-center text-gray-500">
          No audit logs found.
        </div>

        <!-- Audit Logs Table -->
        <div *ngIf="!(loading$ | async) && logs.length > 0" class="mt-8">
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Resource</th>
                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Details</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <tr *ngFor="let log of logs" class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {{ log.createdAt | date:'medium' }}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div *ngIf="log.user?.firstName; else userId">
                    {{ log.user?.firstName }} {{ log.user?.lastName }}
                    <div class="text-xs text-gray-400">{{ log.user?.email }}</div>
                  </div>
                  <ng-template #userId>
                    <span>ID: {{ log.userId }}</span>
                  </ng-template>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                  <span
                    class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full"
                    [ngClass]="{
                      'bg-green-100 text-green-800': log.action === 'create',
                      'bg-yellow-100 text-yellow-800': log.action === 'update',
                      'bg-red-100 text-red-800': log.action === 'delete',
                      'bg-purple-100 text-purple-800': log.action === 'login' || log.action === 'logout'
                    }"
                  >
                    {{ log.action | uppercase }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {{ log.resource }}
                  <span *ngIf="log.resourceId" class="text-xs text-gray-400">#{{ log.resourceId }}</span>
                </td>
                <td class="px-6 py-4 text-sm text-gray-500">
                  {{ log.details || '-' }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      </ng-container>
    </div>
  `
})
export class AuditLogListComponent implements OnInit, OnDestroy {
  auditLogs$: Observable<AuditLog[]>;
  loading$: Observable<boolean>;
  error$: Observable<any>;
  actionTypes$: Observable<string[]>;
  resourceTypes$: Observable<string[]>;
  userIds$: Observable<number[]>;

  filterForm: FormGroup;

  private destroy$ = new Subject<void>();

  constructor(
    private store: Store<AppState>,
    private fb: FormBuilder
  ) {
    this.auditLogs$ = this.store.select(selectFilteredAuditLogs);
    this.loading$ = this.store.select(selectAuditLogLoading);
    this.error$ = this.store.select(selectAuditLogError);
    this.actionTypes$ = this.store.select(selectUniqueActionTypes);
    this.resourceTypes$ = this.store.select(selectUniqueResourceTypes);
    this.userIds$ = this.store.select(selectUniqueUserIds);

    // Initialize filter form
    this.filterForm = this.fb.group({
      action: [''],
      resource: [''],
      userId: ['']
    });
  }

  ngOnInit(): void {
    // Load audit logs
    this.store.dispatch(AuditLogActions.loadAuditLogs());

    // Subscribe to filter form changes
    this.filterForm.valueChanges
      .pipe(takeUntil(this.destroy$))
      .subscribe(filters => {
        const processedFilters: {
          action?: string;
          resource?: string;
          userId?: number;
        } = {};

        if (filters.action) {
          processedFilters.action = filters.action;
        }

        if (filters.resource) {
          processedFilters.resource = filters.resource;
        }

        if (filters.userId && filters.userId !== '') {
          processedFilters.userId = parseInt(filters.userId, 10);
        }

        this.store.dispatch(AuditLogActions.filterAuditLogs({ filters: processedFilters }));
      });

    // Add a small delay before dispatching to ensure token is set
    setTimeout(() => {
      this.store.dispatch(AuditLogActions.loadAuditLogs());
    }, 500);
  }

  clearFilters(): void {
    this.filterForm.reset({
      action: '',
      resource: '',
      userId: ''
    });
    this.store.dispatch(AuditLogActions.clearAuditLogFilters());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}