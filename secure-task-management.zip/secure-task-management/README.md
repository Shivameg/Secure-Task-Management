# Secure Task Management System

A full-stack application implementing role-based access control (RBAC) for secure task management, built with NestJS, Angular, and NgRx in an NX monorepo.

## Architecture Overview

### Monorepo Structure (NX Workspace)

- **apps/**
  - **api/** → NestJS backend with TypeORM
  - **dashboard/** → Angular frontend with NgRx and TailwindCSS
- **libs/**
  - **data/** → Shared TypeScript interfaces & DTOs
  - **auth/** → Reusable RBAC logic and decorators

## Setup Instructions

### Prerequisites

- Node.js (v20+)
- npm (v10+)
- SQLite or PostgreSQL

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd secure-task-management
```

2. Install dependencies:
```bash
npm install
```

3. Start the backend API:
```bash
npx nx serve api
```

4. Start the frontend dashboard:
```bash
npx nx serve dashboard
```

5. Open your browser and navigate to `http://localhost:4200`

## Data Model Explanation

The system uses the following data models:

### Users
- Basic user information (email, name)
- Authentication credentials
- Role assignment (Owner, Admin, Viewer)
- Organization membership

### Organizations
- Two-level hierarchical structure
- Parent-child relationships
- Organizational unit for access control scope

### Roles & Permissions
- Owner: Full system access
- Admin: Organization-level management
- Viewer: Limited read/update access
- Hierarchical inheritance

### Tasks
- Core resource being managed
- Contains metadata (title, description, status)
- Categorization (Work, Personal)
- Priority levels
- Organization-scoped

### Audit Logs
- Activity tracking
- User actions (CRUD operations)
- Resource access logs
- Timestamp tracking

## Access Control Implementation

### Role-Based Access Control (RBAC)

The system implements a comprehensive RBAC model:

1. **Role Hierarchy**
   - Owner > Admin > Viewer
   - Higher roles inherit all permissions from lower roles

2. **Permission Checks**
   - Guards at controller level
   - Decorators for fine-grained control
   - Resource-specific permissions

3. **Organizational Scoping**
   - Data access limited by organization
   - Parent-child org relationships
   - Cross-org isolation

4. **Audit Logging**
   - All access attempts are logged
   - Success/failure tracking
   - Viewable by Owner/Admin roles

## API Documentation

### Authentication
- `POST /api/auth/register` - Create a new user account
- `POST /api/auth/login` - Authenticate and receive JWT token
- `POST /api/auth/logout` - Invalidate current session
- `POST /api/auth/me` - Get current user profile

### Task Management
- `GET /api/tasks` - List accessible tasks (scoped to role/org)
- `GET /api/tasks/:id` - Get a specific task
- `POST /api/tasks` - Create a new task
- `PUT /api/tasks/:id` - Update a task
- `DELETE /api/tasks/:id` - Delete a task

### Audit Logging
- `GET /api/audit-log` - View system access logs (Owner/Admin only)

## Example Requests/Responses

### Login

**Request:**
```json
POST /api/auth/login
{
  "email": "admin@example.com",
  "password": "securepassword"
}
```

**Response:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "email": "admin@example.com",
    "firstName": "Admin",
    "lastName": "User",
    "role": "admin",
    "organizationId": 1
  }
}
```

### Creating a Task

**Request:**
```json
POST /api/tasks
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
{
  "title": "Complete project documentation",
  "description": "Finish writing the technical specs",
  "status": "todo",
  "category": "work",
  "priority": 2,
  "dueDate": "2023-05-20T00:00:00.000Z"
}
```

**Response:**
```json
{
  "id": 1,
  "title": "Complete project documentation",
  "description": "Finish writing the technical specs",
  "status": "todo",
  "category": "work",
  "priority": 2,
  "dueDate": "2023-05-20T00:00:00.000Z",
  "userId": 1,
  "organizationId": 1,
  "createdAt": "2023-05-01T10:30:00.000Z",
  "updatedAt": "2023-05-01T10:30:00.000Z"
}
```

## Future Considerations

### Security Enhancements
- Implement JWT refresh tokens
- Add CSRF protection
- Enable rate limiting
- Add MFA support

### Performance Improvements
- RBAC caching mechanisms
- Query optimization for large organizations
- Pagination for resource-heavy endpoints

### Advanced Features
- Complex role delegation
- Custom permission sets
- Time-based access controls
- Third-party authentication integration

## Development

### Running tests
```bash
# Run API tests
npx nx test api

# Run dashboard tests
npx nx test dashboard
```

### Building for production
```bash
# Build the API
npx nx build api

# Build the dashboard app
npx nx build dashboard
```