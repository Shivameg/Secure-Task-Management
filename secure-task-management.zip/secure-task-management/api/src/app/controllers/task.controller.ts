import { Controller, Get, Post, Put, Delete, Body, Param, UseGuards, Request } from '@nestjs/common';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { RoleGuard, PermissionGuard, Permissions } from '@secure-task-management/auth';
import { PermissionAction, PermissionResource, CreateTaskDto, UpdateTaskDto } from '@secure-task-management/data';
import { TaskService } from '../services/task.service';

@Controller('tasks')
@UseGuards(JwtAuthGuard)
export class TaskController {
  constructor(private taskService: TaskService) {}

  @Post()
  @UseGuards(PermissionGuard)
  @Permissions(PermissionAction.CREATE, PermissionResource.TASK)
  async createTask(@Body() createTaskDto: CreateTaskDto, @Request() req) {
    return this.taskService.create(createTaskDto, req.user);
  }

  @Get()
  @UseGuards(PermissionGuard)
  @Permissions(PermissionAction.READ, PermissionResource.TASK)
  async findAll(@Request() req) {
    return this.taskService.findAll(req.user);
  }

  @Get(':id')
  @UseGuards(PermissionGuard)
  @Permissions(PermissionAction.READ, PermissionResource.TASK)
  async findOne(@Param('id') id: string, @Request() req) {
    return this.taskService.findOne(+id, req.user);
  }

  @Put(':id')
  @UseGuards(PermissionGuard)
  @Permissions(PermissionAction.UPDATE, PermissionResource.TASK)
  async update(@Param('id') id: string, @Body() updateTaskDto: UpdateTaskDto, @Request() req) {
    return this.taskService.update(+id, updateTaskDto, req.user);
  }

  @Delete(':id')
  @UseGuards(PermissionGuard)
  @Permissions(PermissionAction.DELETE, PermissionResource.TASK)
  async remove(@Param('id') id: string, @Request() req) {
    return this.taskService.remove(+id, req.user);
  }
}