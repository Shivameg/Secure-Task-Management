import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { RoleGuard, Roles, Permissions, PermissionGuard } from '@secure-task-management/auth';
import { UserRole, PermissionAction, PermissionResource } from '@secure-task-management/data';
import { AuditLogService } from '../services/audit-log.service';

@Controller('audit-log')
@UseGuards(JwtAuthGuard, RoleGuard)
@Roles(UserRole.OWNER, UserRole.ADMIN)
export class AuditLogController {
  constructor(private auditLogService: AuditLogService) {}

  @Get()
  @UseGuards(PermissionGuard)
  @Permissions(PermissionAction.READ, PermissionResource.AUDIT_LOG)
  async findAll(@Request() req) {
    return this.auditLogService.findAll(req.user);
  }
}