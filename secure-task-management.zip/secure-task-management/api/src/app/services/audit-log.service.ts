import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuditLog } from '../entities/audit-log.entity';
import { UserRole, AuditAction } from '@secure-task-management/data';
import { AuditLoggerService } from '@secure-task-management/auth';

@Injectable()
export class AuditLogService {
  constructor(
    @InjectRepository(AuditLog)
    private auditLogRepository: Repository<AuditLog>,
    private auditLoggerService: AuditLoggerService,
  ) {}

  async findAll(user: any): Promise<AuditLog[]> {
    // For owners, show all logs
    if (user.role === UserRole.OWNER) {
      const logs = await this.auditLogRepository.find({
        relations: ['user'],
        order: { createdAt: 'DESC' },
      });

      // No need to log READ actions

      return logs;
    }

    // For admins, show logs from their organization
    const logs = await this.auditLogRepository
      .createQueryBuilder('log')
      .leftJoinAndSelect('log.user', 'user')
      .where('user.organizationId = :orgId', { orgId: user.organizationId })
      .orderBy('log.createdAt', 'DESC')
      .getMany();

    // No need to log READ actions

    return logs;
  }
}