import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Task } from '../entities/task.entity';
import { CreateTaskDto, UpdateTaskDto, UserRole, AuditAction } from '@secure-task-management/data';
import { AuditLoggerService } from '@secure-task-management/auth';

@Injectable()
export class TaskService {
  constructor(
    @InjectRepository(Task)
    private taskRepository: Repository<Task>,
    private auditLoggerService: AuditLoggerService,
  ) {}

  async create(createTaskDto: CreateTaskDto, user: any): Promise<Task> {
    const newTask = this.taskRepository.create({
      ...createTaskDto,
      userId: user.id,
      organizationId: createTaskDto.organizationId || user.organizationId,
    });

    const savedTask = await this.taskRepository.save(newTask);
    
    // Log the action
    await this.auditLoggerService.logAction(
      user.id,
      AuditAction.CREATE,
      'task',
      savedTask.id,
      `Task created: ${savedTask.title}`
    );

    return savedTask;
  }

  async findAll(user: any): Promise<Task[]> {
    // Apply RBAC filtering
    let query = this.taskRepository.createQueryBuilder('task');

    // If Owner or Admin, can view all tasks in their organization and sub-organizations
    if (user.role === UserRole.OWNER || user.role === UserRole.ADMIN) {
      query = query.where('task.organizationId = :orgId', { orgId: user.organizationId });
    } else {
      // Viewers can only see their own tasks
      query = query.where('task.userId = :userId', { userId: user.id });
    }

    const tasks = await query.getMany();
    
    // No need to log READ actions

    return tasks;
  }

  async findOne(id: number, user: any): Promise<Task> {
    const task = await this.taskRepository.findOne({ where: { id } });
    
    if (!task) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }

    // Check if user has access to this task
    if (
      user.role !== UserRole.OWNER && 
      user.role !== UserRole.ADMIN && 
      task.userId !== user.id
    ) {
      throw new ForbiddenException('You do not have permission to access this task');
    }

    // No need to log READ actions

    return task;
  }

  async update(id: number, updateTaskDto: UpdateTaskDto, user: any): Promise<Task> {
    const task = await this.findOne(id, user);
    
    // Additional permission check for non-owners/admins
    if (
      user.role !== UserRole.OWNER && 
      user.role !== UserRole.ADMIN && 
      task.userId !== user.id
    ) {
      throw new ForbiddenException('You do not have permission to update this task');
    }

    const updatedTask = await this.taskRepository.save({
      ...task,
      ...updateTaskDto,
    });

    // Log the action
    await this.auditLoggerService.logAction(
      user.id, 
      AuditAction.UPDATE, 
      'task', 
      updatedTask.id, 
      `Task updated: ${updatedTask.title}`
    );

    return updatedTask;
  }

  async remove(id: number, user: any): Promise<void> {
    const task = await this.findOne(id, user);
    
    // Additional permission check for non-owners/admins
    if (
      user.role !== UserRole.OWNER && 
      user.role !== UserRole.ADMIN && 
      task.userId !== user.id
    ) {
      throw new ForbiddenException('You do not have permission to delete this task');
    }

    await this.taskRepository.remove(task);
    
    // Log the action
    await this.auditLoggerService.logAction(
      user.id, 
      AuditAction.DELETE, 
      'task', 
      id, 
      `Task deleted: ${task.title}`
    );
  }
}