import { Injectable, UnauthorizedException, ConflictException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { User } from '../entities/user.entity';
import { UserLoginDto, CreateUserDto, AuditAction } from '@secure-task-management/data';
import { AuditLoggerService } from '@secure-task-management/auth';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
    private jwtService: JwtService,
    private auditLoggerService: AuditLoggerService,
  ) {}

  async register(createUserDto: CreateUserDto) {
    // Check if user already exists
    const existingUser = await this.userRepository.findOne({ 
      where: { email: createUserDto.email } 
    });
    
    if (existingUser) {
      throw new ConflictException('Email already exists');
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(createUserDto.password, 12);

    // Create user
    const newUser = this.userRepository.create({
      ...createUserDto,
      password: hashedPassword,
    });

    const savedUser = await this.userRepository.save(newUser);

    // Log the action
    this.auditLoggerService.logAction(
      savedUser.id,
      AuditAction.CREATE,
      'user',
      savedUser.id,
      `User registered: ${savedUser.email}`
    );

    // Return user without password
    const { password, ...result } = savedUser;
    return result;
  }

  async login(userLoginDto: UserLoginDto) {
    const user = await this.userRepository.findOne({ 
      where: { email: userLoginDto.email } 
    });

    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const isPasswordValid = await bcrypt.compare(userLoginDto.password, user.password);

    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const payload = { 
      sub: user.id, 
      email: user.email,
      role: user.role,
      organizationId: user.organizationId,
    };

    // Log the action
    await this.auditLoggerService.logAction(
      user.id,
      AuditAction.LOGIN,
      'auth',
      null,
      `User login: ${user.email}`
    );

    return {
      accessToken: this.jwtService.sign(payload),
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        organizationId: user.organizationId,
      },
    };
  }

  async logout(user: any) {
    // Log the action
    await this.auditLoggerService.logAction(
      user.id,
      AuditAction.LOGOUT,
      'auth',
      null,
      `User logout: ${user.email}`
    );

    return { message: 'Logged out successfully' };
  }

  async getProfile(user: any) {
    const userEntity = await this.userRepository.findOne({ 
      where: { id: user.id }, 
      select: ['id', 'email', 'firstName', 'lastName', 'role', 'organizationId', 'createdAt', 'updatedAt']
    });

    if (!userEntity) {
      throw new UnauthorizedException('User not found');
    }

    return userEntity;
  }
}