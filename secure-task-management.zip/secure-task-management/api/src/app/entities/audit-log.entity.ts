import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { AuditAction } from '@secure-task-management/data';
import { User } from './user.entity';

@Entity('audit_logs')
export class AuditLog {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  userId: number;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column({
    type: 'text',
  })
  action: AuditAction;

  @Column()
  resource: string;

  @Column({ nullable: true })
  resourceId: number;

  @Column({ nullable: true, type: 'text' })
  details: string;

  @CreateDateColumn()
  createdAt: Date;
}