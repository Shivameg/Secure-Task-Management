import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { TaskStatus, TaskCategory } from '@secure-task-management/data';
import { User } from './user.entity';
import { Organization } from './organization.entity';

@Entity('tasks')
export class Task {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  title: string;

  @Column({ nullable: true, type: 'text' })
  description: string;

  @Column({
    type: 'text',
    default: TaskStatus.TODO
  })
  status: TaskStatus;

  @Column({
    type: 'text',
    default: TaskCategory.WORK
  })
  category: TaskCategory;

  @Column({ nullable: true })
  dueDate: Date;

  @Column({ default: 1 })
  priority: number;

  @Column()
  userId: number;

  @ManyToOne(() => User, user => user.tasks)
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column()
  organizationId: number;

  @ManyToOne(() => Organization, organization => organization.tasks)
  @JoinColumn({ name: 'organizationId' })
  organization: Organization;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}