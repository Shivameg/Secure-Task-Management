import { Module } from '@nestjs/common';
import { TypeOrmModule, getRepositoryToken } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { ConfigModule } from '@nestjs/config';
import { Repository } from 'typeorm';

import { AppController } from './app.controller';
import { AppService } from './app.service';

// Config
import { databaseConfig } from './config/database.config';
import { jwtConfig } from './config/jwt.config';

// Entities
import { User } from './entities/user.entity';
import { Organization } from './entities/organization.entity';
import { Task } from './entities/task.entity';
import { AuditLog } from './entities/audit-log.entity';

// Services
import { TaskService } from './services/task.service';
import { AuthService } from './services/auth.service';
import { AuditLogService } from './services/audit-log.service';
import { AuditLoggerService } from '@secure-task-management/auth';

// Controllers
import { TaskController } from './controllers/task.controller';
import { AuthController } from './controllers/auth.controller';
import { AuditLogController } from './controllers/audit-log.controller';

// Strategies
import { JwtStrategy } from './strategies/jwt.strategy';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    TypeOrmModule.forRoot(databaseConfig),
    TypeOrmModule.forFeature([User, Organization, Task, AuditLog]),
    PassportModule,
    JwtModule.register(jwtConfig),
  ],
  controllers: [
    AppController,
    TaskController,
    AuthController,
    AuditLogController,
  ],
  providers: [
    AppService,
    TaskService,
    AuthService,
    AuditLogService,
    {
      provide: 'AUDIT_LOG_REPOSITORY',
      useFactory: (repository: Repository<AuditLog>) => repository,
      inject: [getRepositoryToken(AuditLog)],
    },
    AuditLoggerService,
    JwtStrategy,
  ],
})
export class AppModule {}